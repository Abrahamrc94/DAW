//EJERCICIOS HECHOS EN INGLÉS Y COMENTADOS HASTA EL FINAL.

/*
//BOLETIN JS BASICO

//EJ.1
var name = prompt('Type your name please.');
var age = prompt('Type your age please.');

console.log(`Hello ${name}, you are ${age} years old and next year you will be ${parseInt(age)+1} years old.`);

//EJ.2
var b;
var h;
var r;
var area;
var question = prompt('Choose the figure to calculate the area. -- a)Triangle -- b)Rectangle -- c) Circle.');

if(question == 'a'){
    b = prompt('Type base');
    h = prompt('Type height');
    area = (b*h)/2;
    console.log(area);
}else if(question == 'b'){
    b = prompt('Type base');
    h = prompt('Type height');
    area = (b*h);
    console.log(area);
}else if(question == 'c'){
    r = prompt('Type radio');
    area = Math.PI * (Math.pow(r,2));
    console.log(area);
}

//EJ.3
var iteration = prompt('Type a number');

for(var i = 1; i <= iteration; i++){
    if(i%2 == 0){
        console.log(i + ' - This number is even');
    }else{
        console.log(i + ' - This number is odd');
    }
}

//EJ.4
var integer = prompt('Type an integer greater than 1');
var prime = true;

for(var i = 2; i < integer; i++){
    if(integer%i == 0){
        prime = false;
        break;
    }
}if(prime){
    console.log('The number is prime');
}else{
    console.log('The number is not prime');
}

//EJ.5
var numberInt = prompt('Type an integer grater than 0');
var numberAux = numberInt;

for(var i = 1; i < numberInt; i++){
    numberAux = numberAux * i;
}console.log(numberAux);

//EJ.6
var numberTotal = 0;
var counter = 0;

do{
    numberTotal = numberTotal + parseInt((Math.random()*10));
    counter++;
}while(numberTotal <= 50);
console.log('Total value: ' + numberTotal);
console.log('Maximum count: ' + counter);

//EJ.7

var array1 = [1,2,3,4,5];
var arrayEven = new Array();
var arrayOdd = new Array();
var numberArray = 0;
var numberRandom;

for(var i = 0; i < array1.length; i++){
    numberRandom = parseInt((Math.random()*10));
    numberArray = array1[i] * numberRandom;
    console.log(array1[i]  + ' x ' + numberRandom + ' = ' + numberArray);
    if(numberArray%2 == 0){
        arrayEven.push(numberArray);
    }else{
        arrayOdd.push(numberArray);
    }
}
console.log(arrayEven);
console.log(arrayOdd);

//EJ.8
const letras = ['T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E', 'T'];
var dni = prompt('Type 8 numbers');

if(dni.length == 8){
    this.dni = dni + letras[parseInt(dni%23)];
    console.log(dni);
}else{
    console.log('Error');
}

//EJ.9
const arrayVocal = ['a', 'e', 'i', 'o', 'u'];
var counter1 = 0;
var word = prompt('Type a word');
var wordAux = word.split('');

for(var i = 0; i < arrayVocal.length; i++){
    for(var j = 0; j < wordAux.length; j++){
        if(arrayVocal[i] == wordAux[j]){
            wordAux.splice(j,1);
            counter1++;
        }
    }
}
console.log('Vowel: ' + counter1);
console.log('Consonants: ' + wordAux.length);
console.log('Lenght: ' + word.length);

//EJ.10
const arrayColour = ["azul", "amarillo", "rojo", "verde", "rosa"];
var colour = prompt('Type a colour');
var bool = false;

for(var i = 0; i < arrayColour.length; i++){
    if(arrayColour[i] == colour){
        bool = true;
        break;
    }
}if(bool == true){
    console.log('Exists');
}else{
    console.log('Not exists');
}
*/
