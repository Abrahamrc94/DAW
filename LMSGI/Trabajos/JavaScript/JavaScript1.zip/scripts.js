//PRIMER EJERCICIO
/*
//Declaramos variables
let numero = -4;
let palabra = "Hola mundo";
let respuesta = true;
//Constante
const PI = 3.14;

//Modificamos el numero y mostramos por pantalla todo
numero = 54;
console.log(numero);
console.log(palabra);
console.log(respuesta);
console.log(PI);

//Inicializamos variable sin declarar 
//num = 3;

//Modificamos la constante
//PI = 3.1415;

//SEGUNDO EJERCICIO

//Declaramos variables
let numero1 = 5;
let numero2 = 2;
let nombre = "Jose";

console.log(numero1 + numero2);
console.log(numero1 - numero2);
console.log(numero1 * numero2);
console.log(numero1 / numero2);
console.log(numero1 % numero2);
console.log("Hola " + nombre);

//TERCER EJERCICIO

//Declaramos variables
let a = 5;

//Incrementamos
console.log(a);
console.log(a++);
console.log(a);
console.log(++a);
console.log(a);

//Decrementamos
console.log(a);
console.log(a--);
console.log(a);
console.log(--a);
console.log(a);

//Sumamos y restamos
console.log(a+3);
console.log(a+=3);
console.log(a-=3);

//CUARTO EJERCICIO

//Declaramos variables

let cadena ="Hola Mundo";
let nombre1 = 'Juan Mateo';
let apellido = 'Marcelo';
let edad = 25;


console.log(cadena.length);
console.log(cadena.toUpperCase());
console.log(cadena.toLowerCase());
console.log(cadena.indexOf('o'));
console.log(cadena.indexOf('Hola'));
console.log(cadena.replace('Mundo', 'Youtube'));
console.log(cadena.substring(4));
console.log(cadena.startsWith('h'));
console.log(cadena.startsWith('H'));
console.log('r'.repeat(10));
console.log(`Hola ${nombre1} ${apellido}. Tienes ${edad} años.`);

//QUINTO EJERCICIO

console.log(Math.round(Math.random()*100));
console.log(Math.PI);
console.log(Math.round(Math.random()*(10-5)+5));
console.log(Math.sign(-5));
console.log(Math.sign(0));
console.log(Math.sign(5));

//SEXTO EJERCICIO

//EJ.1

let num = 0;

if(num < 0){
    console.log(`${num} < 0`);
}else if(num == 0){
    console.log(`${num} = 0`);
}else{
    console.log(`${num} > 0`);
}

//EJ.2

let num1 = 5;
let num2 = 0;

if(num1 > 0 && num2 > 0){
    console.log('Ambos son mayores a cero');
}else if(num1 > 0 || num2 > 0){
    console.log('Uno de ellos es mayor a cero');
}

//EJ.3

let cadena1 = 'VARa';

if(cadena1.length > 4){
    console.log(`${cadena1} tiene mas de 4 letras`)
}else if(cadena1.length == 4){
    console.log(`${cadena1} tiene 4 letras`)
}else{
    console.log(`${cadena1} tiene menos de 4 letras`)
}

//EJ.4

let number1 = prompt('Escriba su primer numero');
let number2 = prompt('Escriba su segundo numero distinto del primero');
let number3 = prompt('Escriba su tercero numero distinto del primero y segundo');

if((number1 > number2 && number1 > number3) && (number2 > number3)){
    console.log(number1, number2, number3);
}else if((number1 > number2 && number1 > number3) && (number2 < number3)){
    console.log(number1, number3, number2);
}

else if((number2 > number1 && number2 > number3) && (number1 < number3)){
    console.log(number2, number3, number1);
}else if((number2 > number1 && number2 > number3) && (number1 > number3)){
    console.log(number2, number1, number3);
}

else if((number3 > number2 && number3 > number1) && (number2 > number1)){
    console.log(number3, number2, number1);
}else if((number3 > number2 && number3 > number1) && (number2 < number1)){
    console.log(number3, number1, number2);
}


//EJ.5

//EJ.6


var numeroconsola = prompt('DIGAME SU NUMERO!');
var numeroej6 = (numeroconsola%2) == 0 ? "Par" : "Impar";
console.log(`${numeroej6}`);

//EJ.7

var array = [1,2,3,4,5];

console.log(array[4]);
console.log(array[1] + array[2]);

var arrayC = ['Hola', 'don', 'pepito', 'hola...ETC'];
var segunda = arrayC[1];

console.log(`La palabra ${segunda} tiene ${segunda.length} letras`);


//EJ.8

var numbers = [1, 2, 3, 4, 5, 6];
console.log(numbers.length);

var number = 4;
console.log(Array.isArray(number));
console.log(Array.isArray(numbers));

console.log(numbers.shift());
console.log(numbers.pop());

numbers.unshift(6)
console.log(numbers);

console.log(numbers.reverse().join());

numbers.splice(1, 2,10,23,54);
console.log(numbers);

numbers.splice(2,0,12,14);
console.log(numbers);

//EJ.9

var pass;

while(pass != 'hola'){
    pass = prompt('Escriba su contraseña');
}

do{
    pass = prompt('Escriba su contraseña');
}while(pass != 'hola');
//En en while primero compueba y luego ejecuta, en el do-while es al reves.

for(var i = 10; i > 0; i--){
    console.log(i);
}

var arrayFor = [0,1,2,3,4,5];
for(var i = 0; i < arrayFor.length; i++){
    console.log(`i vale ${i} y el valor de la posicion en el array es ${i}`);
}

var arrayNom = ['Marta', 'Inma', 'Joaquín', 'Javier'];
for(var name of arrayNom){
    console.log(name);
}

for(var i = 0; i < arrayNom.length; i++){
    if(i === 2){
        break;
    }    console.log(i);
}

for(var i = 0; i < arrayNom.length; i++){
    if(i === 1){
        continue;
    }console.log(i);
}
*/