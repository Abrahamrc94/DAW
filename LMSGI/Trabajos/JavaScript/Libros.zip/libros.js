class Libro{

    constructor(titulo, autor, anyo, genero){
        this.titulo = titulo;
        this.autor = autor;
        this.anyo = anyo;
        this.genero = genero;
    }

    mostrar(){
        
        return `Titulo: ${this.titulo}, Autor: ${this.autor}, Anyo: ${this.anyo}, Genero: ${this.genero}`;
    }
    
}

var autores = [];
var save = [];

const seasons = {
    AVENTURA: 'aventura',
    TERROR: 'terror',
    FANTASIA: 'fantasia'
}

var empty;

for(var i = 0; i < 3; i++){

    do{
        empty = false;

        var tit = prompt('Escriba el titulo');
        var aut = prompt('Escriba el autor');
        var an = parseInt(prompt('Escriba el anyo'));
        var gen = prompt('Escriba el genero');

        if((tit.length > 1) && (aut.length > 1) && (an.length > 1 && an.length == 4) && (gen.length > 1 && (gen == AVENTURA || gen == TERROR || gen == FANTASIA))){
            empty = true;
        }else{
            empty = false;
        }

    }while(empty = false);

    save[i] = new Libro(tit, aut, an, gen);
}

function mostrarTodo(){
    for(var i = 0; i < save.length; i++){
        console.log('Libro ' + i +  ': ' + save[i].mostrar());
    }
}

function mostrarAutores(){

    for(var i = 0; i < 3; i++){
        autores[i] = save[i].autor;
    }

    console.log(autores.sort());
}

function mostrarGener(gene){
    for(var i = 0; i < save.length; i++){
        if(save[i].genero == gene){
            console.log(save[i].mostrar());
        }
    }
}

