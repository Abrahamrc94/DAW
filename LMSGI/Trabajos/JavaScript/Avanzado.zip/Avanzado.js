//EJ1
/**
 * Convierte la cadena “Hola Mundo” en un array. Existen 2 métodos que permiten hacerlo. 
 * Hazlo con cada uno de ellos y asigna el resultado a 2 variables distintas.
 */

let cadena = 'Hola mundo';
let variable1 = Array.from(cadena);
let variable2 = cadena.split(" ");
console.log(variable1);
console.group(variable2);

//EJ2
/**
 * Crea un array que contenga las letras b,c,z,a. Muestra por consola el array ordenado.
 */

 let array = ['b','c','z','a'];
console.log(array.sort());

//EJ3
/**
 * Crea un array que contenga los valores 1,8,100,300,3. Utilizando el mismo método anterior, 
 * muestra por consola el array ordenado. ¿Qué pasa? ¿por qué crees que es?
 */

 let array2 = [1, 8, 100, 300, 3];
 console.log(array2.sort((a,b) => a-b));
 console.log(array2.sort());
 //EL SORT A SECAS NO SIRVE PARA NUMERO.

 //EJ4
 /**
  * Crea un array de objetos de usuario. Concretamente serán 6 objetos. Los objetos
  * estarán compuestos por name y por online. Online será true o false indicando si el
  * usuario está online o no. Utilizando reduce, obtén el número de usuarios que están en línea.
  */

  let array3 = [];
  class Usuario{

    constructor(name, online){
        this.name = name;
        this.online = online;
    }

    getBoolean(){
        if(this.online == true){
            return 1;
        }else{
            return 0;
        }
    }
  }

  const uno = new Usuario('Jose', true);
  const dos = new Usuario('Abraham', false);
  const tres = new Usuario('Herminia', true);
  const cuatro = new Usuario('Lucia', false);
  const cinco = new Usuario('Robert', true);
  const seis = new Usuario('Juanma', false);

  array3[0] = uno;
  array3[1] = dos;
  array3[2] = tres;
  array3[4] = cuatro;
  array3[5] = cinco;
  array3[6] = seis;

let numero = array3.reduce((a,b) => a.getBoolean + b.getBoolean);
console.log(numero);