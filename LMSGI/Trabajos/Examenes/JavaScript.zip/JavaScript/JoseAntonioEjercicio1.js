function add(){

    let miPos = document.getElementById("pos").value;
    let miEquip = document.getElementById("equip").value;
    let miPuntos = document.getElementById("puntos").value;

    document.getElementsByTagName('td')[(miPos*3)-2].innerHTML = miEquip;
    document.getElementsByTagName('td')[(miPos*3)-1].innerHTML = miPuntos;


}