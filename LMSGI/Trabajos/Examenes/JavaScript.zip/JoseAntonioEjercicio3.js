let ciudades = [];
ciudades [0] = 'Sevilla';
ciudades [1] = 'Cadiz';
ciudades [2] = 'Huelva';
ciudades [3] = 'Malaga';
ciudades [4] = 'Granada';
ciudades [5] = 'Almeria';
ciudades [6] = 'Jaen';
ciudades [7] = 'Cordoba';

let ciudadesOrden = [];
ciudadesOrden = ciudades;
ciudadesOrden.sort();

document.write('<table border = "1">' + '<tr>' + '<td>' + ciudadesOrden[0]);
document.write('<tr>' + '<td>' + ciudadesOrden[1]);
document.write('<tr>' + '<td>' + ciudadesOrden[2]);
document.write('<tr>' + '<td>' + ciudadesOrden[3]);
document.write('<tr>' + '<td>' + ciudadesOrden[4]);
document.write('<tr>' + '<td>' + ciudadesOrden[5]);
document.write('<tr>' + '<td>' + ciudadesOrden[6]);
document.write('<tr>' + '<td>' + ciudadesOrden[7]);

