function addElemento(){

    let miLista = document.getElementById("lista");
    let miPunto = document.createElement("li");
    let valor = document.getElementById("texto").value;
    let miTexto = document.createTextNode(valor);
    miPunto.appendChild(miTexto);
    miLista.appendChild(miPunto);
}

function eliminarElemento(){

    let miLista = document.getElementById("lista");
    let miPos = parseInt(document.getElementById("posi").value);

    let elementoBorrar = document.getElementsByTagName("li")[miPos];
    miLista.removeChild(elementoBorrar);
}