import static org.junit.Assert.*;
import org.junit.Test;

public class PersonaTest {
	
	@Test
	public void testPersona() {
		Persona persona = new Persona();
		
	}

	@Test
	public void testPersonaStringIntChar() {
		Persona personaParam = new Persona("Jose", 15, 'H');
		
	}

	@Test
	public void testPersonaStringIntCharDoubleDouble() {
		Persona personaParam2 = new Persona("Jose", 15, 'H', 58.8, 1.8);
		
	}

	@Test
	public void testSetNombre() {
		Persona persona = new Persona();
		persona.setNombre("Jose");
	}

	@Test
	public void testSetEdad() {
		Persona persona = new Persona();
		persona.setEdad(15);
	}

	@Test
	public void testSetSexo() {
		Persona persona = new Persona();
		persona.setSexo('H');
	}

	@Test
	public void testSetPeso() {
		Persona persona = new Persona();
		Persona personaParam = new Persona("Jose", 15, 'H');
		persona.setPeso(15.5);
		personaParam.setPeso(54);
	}

	@Test
	public void testSetAltura() {
		Persona persona = new Persona();
		Persona personaParam = new Persona("Jose", 15, 'H');
		persona.setAltura(1.1);
		personaParam.setAltura(1.2);
	}

	@Test
	public void testCalcularIMC() {
		Persona persona = new Persona();
		Persona personaParam = new Persona("Jose", 15, 'H');
		Persona personaParam2 = new Persona("Jose", 15, 'H', 40, 1.6);
		persona.calcularIMC();
		assertEquals(1, persona.calcularIMC());
		personaParam.calcularIMC();
		assertEquals(1, personaParam.calcularIMC());
		personaParam2.calcularIMC();
		assertEquals(-1, personaParam2.calcularIMC());
	}

	@Test
	public void testEsMayorDeEdad() {
		Persona persona = new Persona();
		Persona personaParam = new Persona("Jose", 15, 'H');
		Persona personaParam2 = new Persona("Jose", 15, 'H', 58.8, 1.8);
		persona.esMayorDeEdad();
		personaParam.esMayorDeEdad();
		personaParam2.esMayorDeEdad();
	}

	@Test
	public void testToString() {
		Persona persona = new Persona();
		Persona personaParam = new Persona("Jose", 15, 'H');
		Persona personaParam2 = new Persona("Jose", 15, 'H', 58.8, 1.8);
		persona.toString();
		personaParam.toString();
		personaParam2.toString();
	}

}
