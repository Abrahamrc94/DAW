package boletinJUnit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AccountTest {

	Account acc = new Account("Jose", 23, 22);
	String str;
	
	@Test
	public void testDeposit() {
		
		assertEquals(false, acc.deposit(-5));
		assertEquals(true, acc.deposit(0));
	}
	
	@Test
	public void testWithdraw() {
		
		assertEquals(false, acc.withdraw(25, 20));
		assertEquals(true, acc.withdraw(1, 1));
	}
	
	@Test
	public void testAddBalance() {
		
		acc.addInterest();
		assertEquals(22.99, acc.getBalance(),0.5);
	}
	
	
	 @Test
	 public void testToString() {
		 
		 str = "23	Jose	22,00 �";
		 
		 assertEquals(str, acc.toString());
	 }

}
