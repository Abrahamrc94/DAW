package boletinJUnit;

import static org.junit.Assert.*;

import org.junit.Test;

public class SuscripcionTest {

	@Test
	public void precioMesTest() {
		Subscripcion sp = new Subscripcion(0, 0);
		Subscripcion sp1 = new Subscripcion(0, 1);
		Subscripcion sp2 = new Subscripcion(1, 1);
		Subscripcion sp3 = new Subscripcion(1, 2);
		
		assertEquals(0, sp.precioPorMes(),0);
		assertEquals(0, sp1.precioPorMes(),0);
		assertEquals(1, sp2.precioPorMes(),0);
		assertEquals(1.5, sp3.precioPorMes(),0);
		
	}
	
	@Test 
	public void cancelTest() {
		Subscripcion sp = new Subscripcion(0,1);
		sp.cancel();
		assertEquals(0,sp.getPeriodo());
	}

}
