public class ProductNotFoundException extends Exception {
	public ProductNotFoundException() {
		super();
	}
}
