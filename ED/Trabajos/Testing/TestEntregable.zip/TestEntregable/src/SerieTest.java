import static org.junit.Assert.*;

import org.junit.Test;

public class SerieTest {

	@Test
	public void testIsEntregado() {
		fail("Not yet implemented");
	}

	@Test
	public void testCompareTo() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

	@Test
	public void testEqualsSerie() {
		fail("Not yet implemented");
	}

	@Test
	public void testSerie() {
		fail("Not yet implemented");
	}

	@Test
	public void testSerieStringString() {
		fail("Not yet implemented");
	}

	@Test
	public void testSerieStringIntStringString() {
		fail("Not yet implemented");
	}

}
