import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		System.out.println("�Cuantas lineas quiere?");
		int numero = x.nextInt();
		
		for(int i = 1; i<=numero; i++) {
			System.out.println();
			for(int j = 0; j<i; j++){
				System.out.print("*");
				
			}
		}
		

	}

}
