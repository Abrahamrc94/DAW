import java.util.Scanner;
/**
 * 
 * Clase Alumno, Atributos con nombre y nota media y un metodo asignarNota que imprima si es 
 * menor que 0 o mayor que 10 de error, y si es correcta la nota que la muestre.
 * @author Jose
 *
 */
public class Alumno {
	
	Scanner x = new Scanner(System.in);
	
	//Atributos
	private String nombre;
	private int notaMedia;
	
	public Alumno() {
		
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void asignarNota() {
		
			do{
				System.out.print("Introduzca nota media: ");
				notaMedia = x.nextInt();
				if(notaMedia < 0 || notaMedia > 10) {
					System.out.println("Vuelve a introducir una nota entre 0 y 10");
				}
			}while(notaMedia < 0 || notaMedia > 10);
		}
	
	
	public int getNotaMedia() {
		return notaMedia;
	}


}
