import java.util.Scanner;
/**
 * @author Jose
 *
 */
public class Main {


	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		Alumno alumno = new Alumno();
		
		System.out.print("Introduzca nombre del alumno: ");
		alumno.setNombre(x.nextLine());
		alumno.asignarNota();
		
		System.out.print("Nombre del alumno: " + alumno.getNombre());
		System.out.print("\nNota del alumno: " + alumno.getNotaMedia());

	}

}
