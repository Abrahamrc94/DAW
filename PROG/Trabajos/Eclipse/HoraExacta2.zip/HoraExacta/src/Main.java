
/**
 * @author jose
 *
 */
public class Main {
	
   static public void main(String args[]) {
	   
	  HoraExacta r2 = new HoraExacta();
	  System.out.println(r2);
	   
      HoraExacta r = new HoraExacta(10, 50, 26);

      
      if(r.getHora() >= 0 && r.getHora() <= 24 && r.getMinutos() >= 0 && r.getMinutos() <= 60 && r.getSegundos() >= 0 && r.getSegundos() <= 60) {
    	  System.out.println(r);
    	  
    	  r.comparaHoras();
//          if(r.hora == r2.hora && r.minutos == r2.minutos && r.segundos == r2.segundos) {
//         	   System.out.println("Son iguales");
//            }else {
//          	  System.out.println("No son iguales");
//          }
          System.out.println();
    	  for (int i = 1; i <= 61; i++) { 
    		  r.inc();
    	  }
    	  System.out.println(r); 
    	  r.setHora(20); 
    	  System.out.println(r);
      }else {
    	  System.out.println("ERROR! Vuelve a introducir los datos");
      }
      

      
   }

   
   
}