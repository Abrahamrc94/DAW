/**
 * @author jose
 *
 */
public class Hora12 {
   protected int hora, minutos; 

   public Hora12(int hora, int minutos) { 
      
    	  this.hora = 0; 
    	  this.minutos = 0;
    	  setHora(hora); 
    	  setMinutos(minutos);
      }
      
   

   public void inc() { 
      minutos++;
      if (minutos > 59 && hora <= 60) { 
         minutos = 0; 
         hora++; 
         if (hora > 23 && hora <= 24) { 
            hora = 0; 
         }
      }
   }

   public void setMinutos(int minutos) {
         this.minutos = minutos;
      
      
   }

   public void setHora(int hora) { 
         this.hora = hora;
      
   }

   public String toString() {
      String result;
    	  if(hora < 12) {
    	  	result = hora + ":" + minutos + " am";
    	  	return result;
      	}else if(hora == 12) {
      		result = 12 + ":" + minutos + " pm";
      		return result;
      	}else {
      		result = (hora - 12)+ ":" + minutos + " pm";
      		return result;
      	}
      
      }
   public int getHora() {
	   return hora;
   }
   
   public int getMinutos() {
	   return minutos;
   }
      
   
      
   
}