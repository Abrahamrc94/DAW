
public class Armas {
	
	private String arma_elegida;
	
	public void setArma (String arma) {
		
		arma_elegida = arma;
	}
	
	public String getArma() {
		return "Su arma es: " + arma_elegida;
	}

}
