
public class Heroes {
	
	private String nombre_heroe;
	
	public void setNombre (String nom) {
		
		nombre_heroe = nom;
	}
	
	public String getNombre() {
		return "El nombre de su héroe es: " + nombre_heroe;
	}

}
