
public class Marciano {
	
	private String tipos;
		
		public void setEnemigo (String tipo) {
			
			tipos = tipo;
		}
		
		public String getEnemigo() {
			return "Su enemigo es: " + tipos;
		}

}