
public class Intentos {
		 
		 final int INTENTOS = 3;
		 
		 public String getIntentos() {
			 return "Tiene: " + INTENTOS + " intentos.";
		 }
		 
}
