import java.util.Scanner;

 class Juego {
	

	 
	public static void main (String args[]) {
		
		Scanner x = new Scanner(System.in);
		
		String heroe;
		String arma;
		String enemigo;
		
		Heroes miHeroe = new Heroes();
		Armas miArma = new Armas();
		Marciano miEnemigo = new Marciano();
		Intentos misIntentos = new Intentos();
		
		System.out.print("Pongale nombre a su Heroe: ");
		miHeroe.setNombre(heroe = x.nextLine());
		
		System.out.print("Elija un arma: ");
		miArma.setArma(arma = x.nextLine());
		
		System.out.print("Elija el tipo de enemigo al que enfrentarse, Marciano o Venusiano: ");
		miEnemigo.setEnemigo(enemigo = x.nextLine());
		
		
		
		System.out.println(miHeroe.getNombre());
		System.out.println(miArma.getArma());
		System.out.println(miEnemigo.getEnemigo());
		System.out.println(misIntentos.getIntentos());
		System.out.println("Que comience el juego.");
		 
	}
	
}