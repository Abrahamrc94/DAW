package Ejercicios;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;
import java.util.TreeSet;

/**
 * @author estudiante
 *
 */
public class Ejercicios {

	ArrayList<Integer> numRandom = new ArrayList<Integer>(20);
	
	public Ejercicios() {
		
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList ejercicio1() {
		
		for(int i = 0; i < 20; i++) {
			numRandom.add((int) (Math.random()*100));
		}

		return numRandom;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList ejercicio1Ordenado(){
		
		Collections.sort(numRandom);
		return numRandom;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList ejercicio2() {
		
		Collections.reverse(numRandom);
		return numRandom;
	}
	
	@SuppressWarnings("rawtypes")
	public TreeSet ejercicio3() {
		
		TreeSet<Integer> numRandomReves = new TreeSet<>(Collections.reverseOrder());
		
		while(numRandomReves.size()<20) {
			
			numRandomReves.add((int) (Math.random()*100));
		}return numRandomReves;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList ejercicio4() {
		
		ArrayList<Integer> numRandomReves2 = new ArrayList<Integer>(20);
		
		while(numRandomReves2.size()<20) {
			
			numRandomReves2.add((int) (Math.random()*10));
		}Collections.sort(numRandomReves2, Collections.reverseOrder());
		return numRandomReves2;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList ejercicio5() {
		
		ArrayList<String> listaNombres = new ArrayList<String>();
		@SuppressWarnings("resource")
		Scanner xString = new Scanner(System.in);
		
		boolean encontrado = false;
		String nombre = "";
	
		while(!nombre.equals("fin")) {
			nombre = xString.nextLine();
			for(int i = 0; i < listaNombres.size(); i++) {
				if(!nombre.equals(listaNombres.get(i))) {
					encontrado = false;
				}else if(nombre.equals(listaNombres.get(i))){
					encontrado = true;
					break;
				}
			}
			if(encontrado == false && !nombre.equals("fin")){
				listaNombres.add(nombre);
			}
		}return listaNombres;
	}
	
	@SuppressWarnings("rawtypes")
	public ArrayList ejercicio6() {
		ArrayList<String> listaNombresAlf = new ArrayList<String>();
		
		@SuppressWarnings("resource")
		Scanner xString = new Scanner(System.in);
		
		boolean encontrado = false;
		String nombre = "";
	
		while(!nombre.equals("fin")) {
			nombre = xString.nextLine();
			for(int i = 0; i < listaNombresAlf.size(); i++) {
				if(!nombre.equals(listaNombresAlf.get(i))) {
					encontrado = false;
				}else if(nombre.equals(listaNombresAlf.get(i))){
					encontrado = true;
					break;
				}
			}
			if(encontrado == false && !nombre.equals("fin")){
				listaNombresAlf.add(nombre);
			}
		}
		
		Collections.sort(listaNombresAlf);
		return listaNombresAlf;	
	}
	
	@SuppressWarnings("rawtypes")
	public HashSet ejercicio7() {
		
		ArrayList<String> lista = new ArrayList<String>();
		HashSet<String> lista2 = new HashSet<String>();
		
		@SuppressWarnings("resource")
		Scanner xString = new Scanner(System.in);
		String nombre = "";
		for(int i = 0; i < 10; i++) {
			
			nombre = xString.nextLine();
			lista.add(nombre);
		}
		
		lista2.addAll(lista);
		return lista2;
		
	}
	
	public void ejercicio8() {
		
		ArrayList<String> lista = new ArrayList<String>();
		ArrayList<String> listaRep = new ArrayList<String>();
		HashSet<String> listaNoRep = new HashSet<String>();
		
		@SuppressWarnings("resource")
		Scanner xString = new Scanner(System.in);
		String frase;
		char espacio = ' ';
		String save = "";
		
		frase = xString.nextLine();
		
		for(int i = 0; i < frase.length(); i++) {
			
			if(frase.charAt(i) != espacio) {
				save = save + frase.charAt(i);
			}else if(frase.charAt(i) == espacio) {
				lista.add(save);
				save = "";
			}
			
		}lista.add(save);
		
		for(int i = 0; i < lista.size(); i++) {
			for(int j = i+1; j < lista.size(); j++) {
				if(lista.get(i).equals(lista.get(j))) {
					listaRep.add(lista.get(i));
				}
			}
		}listaNoRep.addAll(lista);
		
		System.out.println(lista);
		System.out.println(listaNoRep);
		System.out.println(listaRep);
	}
}
