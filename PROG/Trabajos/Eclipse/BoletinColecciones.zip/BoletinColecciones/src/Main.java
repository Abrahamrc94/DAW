/**
 * 
 */
import Ejercicios.Ejercicios;
/**
 * @author estudiante
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Ejercicios ej = new Ejercicios();
		
		System.out.println(ej.ejercicio1());
		System.out.println(ej.ejercicio1Ordenado());
		System.out.println(ej.ejercicio2());
		System.out.println(ej.ejercicio3());
		System.out.println(ej.ejercicio4());
		System.out.println(ej.ejercicio5());
		System.out.println(ej.ejercicio6());
		System.out.println(ej.ejercicio7());
		ej.ejercicio8();
	}

}
