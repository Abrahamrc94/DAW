package Vehiculos;
import java.util.Random;

/**
 * @author jose
 *
 */
public class Tractor extends Vehiculo {
	
	//Atributos
	private Random encendido = new Random();
	private int arrancar;
	
	/**
	 * @param arrancar es un entero que sirve para arrancar el tractor mediante un bucle
	 * 
	 */

	//Constructor
	public Tractor() {
		
	}
	
	//SETTERS
	public void setModelo (String modelo) {
		this.modelo = modelo;
	}
	
	public void setMatricula (String mat) {
		matricula = mat;
	}
	
	public void setPeso (int peso) {
		this.peso = peso;
	}
	
	public void setVelocidad (int velocidad) {
		this.velocidad = velocidad - (peso/10);
	}
	
	//Metodo toString sobrecargado
	@Override
	public String toString() {
		return ("Modelo: " + modelo + "\nMatricula: " + matricula + "\nPeso: " + peso + "\nVelocidad: " + velocidad);
	}
	
	//Metodo
	public void Arrancando() {
		
		System.out.println("Arranca la maquina de correr");
		do {
			System.out.println("Arranque su tractorcito pulsando 1");
			arrancar = x.nextInt();
			if(arrancar == 1) {
				motor = encendido.nextBoolean();
				if(motor == true) {
					break;
				}else {
					System.out.println("Vaya! no ha arrancado! Prueba de nuevo");
				}
			}else {
				System.out.println("Hazlo con el 1, que si no no va");
			}
			
			
		}while (motor == false);
		System.out.println("Arrancado!");
	}

}
