package Vehiculos;

import java.util.Scanner;

/**
 * @author jose
 *
 */

//Clase abstract
public abstract class Vehiculo {
	
	//Atributos
	
	/**
	 * @param velocidad es un protected en integer para poder usarlo en todo el paquete y marca la velodidad
	 * @param modelo es un protected en String para poder usarlo en todo el paquete y marca el modelo
	 * @param matricula es un protected en String para poder usarlo en todo el paquete y marca el matricula
	 * @param motor es un protected en boolean para poder usarlo en todo el paquete y marca si el motor está encendido o no
	 * @param peso es un protected en integer para poder usarlo en todo el paquete y marca el peso
	 * @param x es un Scanner para que las clases hijas puedan hacer uso de ello
	 */

	protected double velocidad;
	protected String modelo;
	protected String matricula;
	protected boolean motor = false;
	protected double peso;
	protected Scanner x = new Scanner(System.in);

	//Constructor
	public Vehiculo() {
		
	}
	
	//Metodo abstact para usar en otras clases
	public abstract void Arrancando();

}
