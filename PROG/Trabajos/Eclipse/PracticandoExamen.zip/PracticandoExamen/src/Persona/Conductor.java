package Persona;
import java.util.Random;
import Vehiculos.Coche;

/**
 * @author jose
 */
public class Conductor {
	
	//Atributos
	
	/**
	 * @param peso es un private en String y dice el peso de la persona
	 * @param azar es un que sirve para elegir la opcion en el metodo contestan y dices
	 * @param estado es un boolean que segun si es true o false dará paso a una opcion u otra
	 * @param ver es un Array que nos dice cuantos coches vamos a poder ver delante nuestra
	 */
	
	private String peso;
	private Random azar = new Random();
	private boolean estado;	
	private int[] ver = new int[5];
	
	
	//Iniciamos la clase coche sobrecargada
	Coche ch2 = new Coche(25, 25, "Toyota", "112255T");
	
	//Metodo constructor con parametro
	public Conductor(String peso) {
		
	}
	
	//metodo para decir
	public void dices() {
		estado = azar.nextBoolean();
		
		//condicional
		if(estado == false) {
			System.out.println("¿Le importaria aumentar su velocidad para no ser tortuguitas?");
		}else {
			System.out.println("Pisale yaa!! Madre mia... que desesperación T-T");
		}
	}
	
	//metodo para contestar
	public void contestan() {
		
		estado = azar.nextBoolean();
		
		//condicional
		if(estado == false) {
			System.out.println("Vale perdonadme POR FAVOR!!! T-T");
		}else {
			System.out.println("Callate la boca desgracia de vida!");
		}
	}
	
	//metodo toString
	public String getTu() {
		return ("Tu vas en: " + ch2);
	}
	
	// Metodo con que lanza una excepcion, señalamos cual va a lanzar
	public void cochesVer() throws ArrayIndexOutOfBoundsException {
		
		//Hacemos que corra el codigo con error con un try
		try {
			for(int i = 0; i <= 10; i++) {
				ver[i] = i;
				System.out.println("Puedes ver delante tuya " + ver[i] + " coches");
			}
		}
		//Capturamos el error con el catch
		catch(ArrayIndexOutOfBoundsException exception) {
			System.out.println("\nNormal que no puedas ver mas de 4, no tienes vista de lince, pero vamos, menos mal que lo he programado yo, tienes 10 coches delante");
		}
		//Mostrar por pantalla ese texto en cualquier caso con el finally
		finally {
			System.out.println("\n¿Tranquilo ya? Pues eah, a comerte el atasco, maquina");
		}
	}

}
