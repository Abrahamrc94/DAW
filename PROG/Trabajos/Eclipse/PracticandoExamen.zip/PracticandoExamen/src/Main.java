import Vehiculos.*;
import java.util.Scanner;
import Persona.*;

/**
 * 
 * @author jose
 *@version 2
 */

//Clase main
public class Main {

	//Metodo main
	public static void main(String[] args) {
		
		//Hacemos Scanners
		Scanner y = new Scanner(System.in);
		Scanner x = new Scanner(System.in);
		
		//Atributo
		int opcion;
		
		//Iniciamos los objetos
		Coche ch1 = new Coche();
		Coche ch2 = new Coche(79, 300, "Ferrari", "456789Q");
		Moto mt = new Moto();
		Tractor tr = new Tractor();
		
		Conductor cd = new Conductor("Gordo");
		
		//Bucle para elegir opciones
		do {
			System.out.println("¿Que quiere arrancar? 1.Coche, 2.Moto, 3.Tractor, 0.Salir: ");
			System.out.print("Opcion: ");
			opcion = x.nextInt();
			if(opcion == 1) {
				ch1.setModelo("Nissan");
				ch1.setMatricula("133211P");
				System.out.print("Introduzca el peso de su cochecito: ");
				ch1.setPeso(x.nextInt());
				ch1.setVelocidad(20);
				ch1.Arrancando();
				System.out.println();
				System.out.println(ch1); //Esto llama directamente al toString de la clase.
				System.out.println();
			}else if(opcion == 2) {
				mt.setModelo("Kawasaki");
				mt.setMatricula("133854P");
				System.out.print("Introduzca el peso de su moto: ");
				mt.setPeso(x.nextInt());
				mt.setVelocidad(35);
				mt.Arrancando();
				System.out.println();
				System.out.println(mt); //Esto llama directamente al toString de la clase.
				System.out.println();
			}else if(opcion == 3) {
				tr.setModelo("Mercedes");
				tr.setMatricula("138994P");
				System.out.print("Introduzca el peso de su tractor: ");
				tr.setPeso(x.nextInt());
				tr.setVelocidad(35);
				tr.Arrancando();
				System.out.println();
				System.out.println(tr); //Esto llama directamente al toString de la clase.
				System.out.println();
			}else if(opcion == 0) {
				break;
			}else {
				System.out.println("Ha introducido mal la opcion, vuelva a introducir la opcion a elegir");
			}
			
		}while(opcion != 0);
		
		System.out.println("Tu coche: " + ch2);
		
		System.out.println("Estas en carretera");
		
		cd.getTu();
		System.out.print("\nDices: ");
		cd.dices();
		System.out.println();
		System.out.print("Te dicen: ");
		cd.contestan();
		
		cd.cochesVer();
		
		//Cerramos los Scanner
		y.close();
		x.close();	
	}
	
	

}
