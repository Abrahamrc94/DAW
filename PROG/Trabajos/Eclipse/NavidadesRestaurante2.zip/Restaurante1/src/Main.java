import Almacenes.Almacen;

public class Main {

	public static void main(String[] args) {
		
		Almacen almacen = new Almacen(1, 0.5);
		almacen.calcular();
		
		almacen.addGarbanzos(3);
		almacen.addCalabazas(5);
		System.out.println("Tienes para " + almacen.getComensales() + " personas");
		
		almacen.showGarbanzos();
		almacen.showCalabazas();
		
	}

}
