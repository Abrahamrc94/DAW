package Almacenes;

/**
 * @author Jose
 *
 */
public class Almacen {

	private double calabazas;
	private double garbanzos;
	
	
	public Almacen(double garbanzos, double calabazas) {
		this.garbanzos = garbanzos;
		this.calabazas = calabazas;
	}

	public void calcular() {
		
		double calculo1;
		double calculo2;
		
		calculo1 = ((this.garbanzos/0.33) + (this.calabazas/0.166));
		calculo2 = calculo1/2;
		
		System.out.println("Tienes para " + (int)calculo2 + " personas");
		
	}
	
	public void addCalabazas(double calabazas) {
		this.calabazas = this.calabazas + calabazas;
	}
	
	public void addGarbanzos(double garbanzos) {
		this.garbanzos = this.garbanzos + garbanzos;
	}
	
	public int getComensales() {
		double calculo1;
		double calculo2;
		
		calculo1 = ((this.garbanzos/0.33) + (this.calabazas/0.166));
		calculo2 = calculo1/2;
		return (int)calculo2;
	}
	
	public void showCalabazas() {
		System.out.println(calabazas + " kg de calabazas");
	}
	
	public void showGarbanzos() {
		System.out.println(garbanzos + " kg de garbanzos");
	}
	
}
