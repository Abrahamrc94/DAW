public class CuentaCorriente {
	
	//Atributos
	private double saldo;
	private double limite_descubiero;
	private String nombre;
	private String dni;

	
	//Clase constructora.
	public CuentaCorriente() {
		
		saldo = 0.0;
		limite_descubiero = -50.0;
	}
	
	//Setter de crear cuenta.
	public void crearCuenta(String nombre, String dni) {
		this.nombre = nombre;
		this.dni = dni;
	}
	
	//Setter de sacar dinero.
	public void sacarDinero(double saldoSacar) {
		
		if(saldo - saldoSacar >= limite_descubiero) {
		saldo = saldo - saldoSacar;
		}else {
		System.out.println("No puede sacar esa cantidad, su saldo es de " + saldo + " euros. Su limite de descubierto es " + limite_descubiero + " euros");
		}
	}
	
	//Setter de ingresar dinero.
	public void ingresarDinero(double saldoIngresar) {
		saldo = saldo + saldoIngresar;
	}
	
	//Getter toString de toda información.
	public String toString() {
		return ("Nombre: " + nombre + "\nDNI: " + dni + "\nSaldo: " + saldo);
	}

}
