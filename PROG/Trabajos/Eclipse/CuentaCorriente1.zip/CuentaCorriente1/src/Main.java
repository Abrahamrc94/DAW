import java.util.Scanner;
/**
 * @author jose
 *
 */
public class Main {

	public static void main(String[] args) {
		
		String nombre;
		String dni;
		
		CuentaCorriente cc = new CuentaCorriente();
		
		Scanner x  = new Scanner(System.in);
		
		System.out.println("Crear una cuenta: ");
		System.out.print("Escriba su nombre: " );
		nombre = x.nextLine();
		System.out.print("Escriba su DNI: " );
		dni = x.nextLine();
		cc.crearCuenta(nombre, dni);
		
		System.out.print("Sacar dinero: ");
		cc.sacarDinero(x.nextDouble());	
		
		System.out.print("Ingresar dinero: ");
		cc.ingresarDinero(x.nextDouble());
		
		System.out.println("Datos de su cuenta corriente: " + cc.toString());
		

	}

}
