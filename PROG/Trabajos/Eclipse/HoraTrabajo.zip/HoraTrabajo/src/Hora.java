/**
 * @author Jose
 *
 */
public class Hora {
	
	int hora;
	int minuto;
	
	
	public Hora() {
		
		
	}
	
	public Hora(int hora, int minuto) {
		
	}
	
	public void inc() {
		
		this.hora = ((hora/60) + 1);
	}
	
	public void setMinutos(int minuto) {
		
		do {
			if(minuto >= 0 && minuto <=59) {
			this.minuto = minuto;
			}else {
			System.out.println("Vuelva a introducir un minuto entre 0-59");
			}
		}while(minuto >= 0 && minuto <=59);
	}
	
	public void setHora(int hora) {
		
		do {
			if(hora >= 0 && minuto <= 23) {
			this.hora = hora;
			}else {
			System.out.println("Vuelva a introducir hora");
			}
		}while(hora >= 0 && minuto <= 23);
		
	}
	
}
