import java.util.Scanner;
/**
 * @author Jose
 *
 */
public class Main {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		Hora hora = new Hora();
		
		hora.setHora(x.nextInt());
		hora.setMinutos(x.nextInt());
		hora.inc();
		
	}

}
