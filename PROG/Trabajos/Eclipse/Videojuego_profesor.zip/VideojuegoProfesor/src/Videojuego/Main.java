package Videojuego;

/**
 * @author Jose
 *
 */
public class Main {

	public static void main(String[] args) {
		Videojuego v = new Videojuego();
		
		System.out.println("El enemigo es de color " + v.getEnemigo().getCOLOR_DEFECTO());
		System.out.println("El enemigo tiene " + v.getEnemigo().getNumOjos() + " ojos");
		System.out.println("El enemigo tiene " + v.getEnemigo().getNumPiernas() + " piernas");
		
		v.getEnemigo().atacar();
		
	}

}
