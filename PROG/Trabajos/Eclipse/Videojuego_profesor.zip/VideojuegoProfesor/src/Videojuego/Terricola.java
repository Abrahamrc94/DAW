package Videojuego;

/**
 * @author Jose
 *
 */
public class Terricola {

	public Terricola() {
		
	}

}
