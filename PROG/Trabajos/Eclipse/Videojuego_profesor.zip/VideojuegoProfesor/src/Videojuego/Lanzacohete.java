package Videojuego;

/**
 * @author Jose
 *
 */
public class Lanzacohete {

	public Lanzacohete() {
		
	}

}
