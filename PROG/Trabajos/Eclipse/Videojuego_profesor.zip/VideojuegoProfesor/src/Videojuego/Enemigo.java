package Videojuego;
/**
 * @author Jose
 *
 */
public abstract class Enemigo {
	//Constantes
	protected final String COLOR_DEFECTO = "negro";
	protected final int NUM_OJOS_DEFECTO = 3;
	protected final int NUM_PIERNAS_DEFECTO = 4;
	
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getNumOjos() {
		return numOjos;
	}

	public void setNumOjos(int numOjos) {
		this.numOjos = numOjos;
	}

	public int getNumPiernas() {
		return numPiernas;
	}

	public void setNumPiernas(int numPiernas) {
		this.numPiernas = numPiernas;
	}

	public String getCOLOR_DEFECTO() {
		return COLOR_DEFECTO;
	}

	public int getNUM_OJOS_DEFECTO() {
		return NUM_OJOS_DEFECTO;
	}

	public int getNUM_PIERNAS_DEFECTO() {
		return NUM_PIERNAS_DEFECTO;
	}

	//Atributos
	protected String color = COLOR_DEFECTO;
	protected int numOjos = NUM_OJOS_DEFECTO;
	protected int numPiernas = NUM_PIERNAS_DEFECTO;

//	//Constructor por defecto
//	public Enemigo() {
//		color = "negro";
//		numOjos = 3;
//		numPiernas = 4;
//	}
//	
//	public Enemigo(String color, int numOjos, int numPiernas) {
//		this.color = color;
//		this.numOjos = numOjos;
//		this.numPiernas = numPiernas;
//	}

	//Metodos de la clase
	public void mover() {
		System.out.println("Me estoy moviendo");
	}
	
	public void atacar() {
		System.out.println("Corre corre que te ataco...");
	}
	
	public abstract void disparar();
		
	
	
}
