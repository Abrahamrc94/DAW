package Videojuego;

/**
 * 
 * @author Jose
 *
 */

public class Videojuego {

	//Atributos
	private Enemigo enemigo;
	private Terricola terricola;
	private Lanzacohete lanzacohete;
	
	
	public Videojuego() {
		enemigo = new Marciano("blanco", 3, 3, false);
	}
	
	public void comenzarPartida() {
		System.out.println("La partida ha comenzado");
	}
	
	public void interrumpirPartida() {
		System.out.println("La partida ha sido interrumpida");

	}
	
	public void reanudarPartida() {
		System.out.println("La partida ha sido reanudada");
	}
	
	public void terminarPartida() {
		System.out.println("La partida ha terminado");
	}

	public Enemigo getEnemigo() {
		return enemigo;
	}

	public void setEnemigo(Enemigo enemigo) {
		this.enemigo = enemigo;
	}

	public Terricola getTerricola() {
		return terricola;
	}

	public void setTerricola(Terricola terricola) {
		this.terricola = terricola;
	}

	public Lanzacohete getLanzacohete() {
		return lanzacohete;
	}

	public void setLanzacohete(Lanzacohete lanzacohete) {
		this.lanzacohete = lanzacohete;
	}
	
	

}
