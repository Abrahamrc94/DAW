package Videojuego;

/**
 * @author estudiante
 *
 */
public class Marciano extends Enemigo{

	//Atributos
	private boolean visible;
	
	public Marciano() {
		//Ya estan en enemigos por defecto pero lo especificamos aun asi.
		color = super.COLOR_DEFECTO;
		numOjos = super.NUM_OJOS_DEFECTO;
		numPiernas = super.NUM_PIERNAS_DEFECTO;
		
		this.visible = false;
	}
	
	public Marciano(String color, int numOjos, int numPiernas, boolean visible) {
		this.color = color;
		this.numOjos = numOjos;
		this.numPiernas = numPiernas;
		this.visible = visible;
	}

	@Override
	public void disparar() {
		System.out.println("uy uy que te mato...");
		
	}
	
	public void atacar(int veces) {
		System.out.println("Soy marciano, te miro y te golpeo" + veces + " veces");
	}

}
