package Videojuego;

/**
 * @author estudiante
 *
 */
public class Venusiano extends Enemigo{

	int numCabezas;
	
	public Venusiano() {
		//Ya estan en enemigos por defecto pero lo especificamos aun asi.
		color = super.COLOR_DEFECTO;
		numOjos = super.NUM_OJOS_DEFECTO;
		numPiernas = super.NUM_PIERNAS_DEFECTO;
		
		this.numCabezas = 2;
	}
	
	public Venusiano(String color, int numOjos, int numPiernas, int numCabezas) {
		this.color = color;
		this.numOjos = numOjos;
		this.numPiernas = numPiernas;
		this.numCabezas = numCabezas;
	}

	@Override
	public void disparar() {
		System.out.println("uy uy que te mato wevon...");
		
	}

}
