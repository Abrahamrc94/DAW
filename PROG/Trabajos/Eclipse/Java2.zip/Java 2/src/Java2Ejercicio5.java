import java.util.Scanner;

public class Java2Ejercicio5 {
		public static void main(String[] args) {
			
			Scanner x = new Scanner(System.in);
			
			System.out.print("Introduzca cantidad a convertir a pesetas: ");
			
			double num1 = x.nextDouble();
			final double pesetas = 166.386;
			
			System.out.println(num1 + " Pesetas = " + num1 / pesetas + " Euros");
		}

}
