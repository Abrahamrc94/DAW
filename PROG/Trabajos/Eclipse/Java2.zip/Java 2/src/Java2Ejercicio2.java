
public class Java2Ejercicio2 {
	public static void main (String [] args) {
		String name = "Jose Antonio";
		
		System.out.println(name);
		
	}

}
