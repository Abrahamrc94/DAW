
public class Java2Ejercicio3 {
	public static void main(String[] args) {
		String name = "Jose Antonio";
		String direccion= "Calle pa";
		String tlfn = "999999999";
		
		System.out.println(name + ", " + direccion + ", " + tlfn);
		
	}

}
