import java.util.Scanner;

public class Java2Ejercicio6 {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		
		
		double baseImponible = x.nextDouble();

	    System.out.println("Base imponible		" + baseImponible);
	    System.out.println("IVA           		" + (baseImponible * 0.21));
	    System.out.println("----------------------------\n");
	    System.out.println("Total          		" + (baseImponible * 1.21));

	}

}
