
public class Java2Ejercicio1 {
	public static void main(String[] args) {
		int x = 144;
		int y = 999;
		int suma = x + y;
		int resta = x - y;
		int mult = x * y;
		float div = (float)x / (float)y;
		
		System.out.println(x + ", " + y);
		System.out.println("Suma = " + suma);
		System.out.println("Resta = " + resta);
		System.out.println("Multiplicación = " + mult);
		System.out.println("División = " + div);
	
		
	}
	

}
