/**
 * 
 */
package Lista;

import java.util.Arrays;

/**
 * @author estudiante
 *
 */
public class Lista {

	int[] azar = new int[100];
	int[] completa = new int[100];
	int[] falta = new int[100];
	int numero = 1;
	
	
	 
	public Lista() {
		
	}
	
	public void llenarCompleto() {
		
		for(int i = 0; i < completa.length; i++) {
			
			completa[i] = numero;
			numero++;
		}
	}
	
	public void llenarAzar() {
		for(int i = 0; i < azar.length; i++) {
			int random = (int) (Math.random()*100+1);
			azar[i] = random;
		}
		System.out.println(Arrays.toString(azar));	
	}
	
	public void recorrer() {
		
		//Arrays.sort(azar);
		for(int i = 0; i < completa.length; i++) {
			boolean encontrado = false;
			int contador = 0;
			for(int j = 0; j < azar.length; j++) {
				if(azar[j] != completa[i] && !encontrado) {
					encontrado = true;
					falta[contador + 1] = completa[i];
				}contador++;
			}
		}System.out.println(Arrays.toString(falta));
		int [] faltaArr = Arrays.copyOf(falta,3);
		System.out.println(Arrays.toString(faltaArr));
	}
	

}
