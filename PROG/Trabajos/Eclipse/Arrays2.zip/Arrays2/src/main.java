import Lista.Lista;

/**
 * 
 */

/**
 * @author estudiante
 *
 */
public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Lista l = new Lista();
		
		l.llenarCompleto();
		l.llenarAzar();
		l.recorrer();
	}

}
