
public class Java5Ejercicio4 {

	public static void main(String[] args) {
		
		int num = 20;
		
		for(int i=320; i>=160; i-=num) {
			System.out.println("Resultado: " + i);
		}

	}

}
