import java.util.Scanner;
public class Java5Ejercicio12 {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		System.out.print("Introduzca su numero: ");
		int numero = x.nextInt();
		
		int resultado = 0;
		
		int numero1 = 0;
		int numero2 = 1;
		
			System.out.println("Resultado: 0");
			for(int i=1; i<numero; i++) {
				 
				resultado = (numero1 + numero2);
				numero2 = numero1;
				numero1 = resultado;
				
				System.out.println("Resultado: " + resultado);
		}
	}

}
