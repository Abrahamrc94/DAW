import java.util.Scanner;
public class Java5Ejercicio9 {

	public static void main(String[] args) {
		
		
		Scanner x = new Scanner(System.in);
		
		
		System.out.print("Introduzca número: ");
		
		String numero = x.nextLine();
		int resultado = 0;
		
		
		for (int i=1; i<=numero.length();i++) {
			resultado = i;
		}
		 System.out.println("Resultado: " + resultado + " digitos");
		
	}

}
