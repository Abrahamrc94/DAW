import java.util.Scanner;

public class Java5Ejercicio7 {

	public static void main(String[] args) {
		
		int clave;
		
		for(int i = 1; i<=4; i++) {
			System.out.print("Introduzca clave de 4 digitos: ");
			Scanner x = new Scanner(System.in);
			clave = x.nextInt();
			if(clave == 5454) {
				System.out.println("La caja fuerte se ha abierto satisfactoriamente");
				break;
			}else {
				System.out.println("Lo siento, esa no es la combinación");
			}
			
		}

	}

}
