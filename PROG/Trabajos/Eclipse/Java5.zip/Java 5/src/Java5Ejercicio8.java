import java.util.Scanner;

public class Java5Ejercicio8 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca numero: ");
		Scanner x = new Scanner(System.in);
		int numero = x.nextInt();
		
		int i = 1;
		
		while (i<=10) {
			System.out.println(numero * i);
			i++;
		}

	}

}
