
public class Java5Ejercicio2 {

	public static void main(String[] args) {
		
		int num = 1;
		
		while (num <= 20) {
			System.out.println("Multiplos de 5 hasta 100: " + 5*num);
			num++;
		}

	}

}
