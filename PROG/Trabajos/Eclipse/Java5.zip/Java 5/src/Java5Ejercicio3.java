
public class Java5Ejercicio3 {

	public static void main(String[] args) {
		
		int num = 1;
		
		do {
			System.out.println("Multiplos de 5 hasta 100: " + 5 * num);
			num++;
		}while (num <= 20);

	}

}
