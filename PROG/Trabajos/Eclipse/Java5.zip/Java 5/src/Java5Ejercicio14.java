import java.util.Scanner;

public class Java5Ejercicio14 {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		System.out.print("Escriba la base: ");
		final int BASE = x.nextInt();
		
		System.out.print("Escriba el exponente: ");
		final int EXP = x.nextInt();
		
		int i = 1;
		int resultado = 1;
		
		//DO-WHILE
		
		do {
			resultado = (resultado * BASE);
			i++;
		}while(i<=EXP && i > 0);
		
		//WHILE
		
		/*while(i<=EXP && i > 0) {
			resultado = (resultado * BASE);
			i++;
			
		}*/
		
		System.out.println("Resultado: " + resultado);

	}

}
