
public class Java5Ejercicio5 {

	public static void main(String[] args) {
		
		int i = 320;
		
		while(i>=160) {
			System.out.println("Solucion: " + i);
			i-=20;
		}

	}

}
