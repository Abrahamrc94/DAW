import java.util.Scanner;

/**
 * @see www.google.com
 * @version 1.8
 * 
 * @author Jose
 *
 */

public class Java5Ejercicio10 {
	
	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		System.out.print("Introduzca un numero: ");
		String numero = x.nextLine();
		int resultado = 0;
		
		for(int i = 1; i<= numero.length(); i++) {
			resultado++;
		}System.out.print("Tiene: " + resultado + " Digitos");

	}

}
