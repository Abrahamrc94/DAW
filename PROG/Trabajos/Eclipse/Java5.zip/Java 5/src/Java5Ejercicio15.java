import java.util.Scanner;
public class Java5Ejercicio15 {

	public static void main(String[] args) {
		
		System.out.println("Introduzca 2 numeros: ");
		
		Scanner x = new Scanner(System.in);
		
		int numero1 = x.nextInt();
		int numero2 = x.nextInt();
		
		for(int i=1; i<=numero2; i++) {
			System.out.println("Solucion: " + numero1 + "^" + i);
			
		}
		

	}

}
