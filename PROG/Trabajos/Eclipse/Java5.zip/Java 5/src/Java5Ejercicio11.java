import java.util.Scanner;
public class Java5Ejercicio11 {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		System.out.print("Introduzca base: ");
		int base = x.nextInt();
		
		int resultado2 = 1;
		int resultado3 = 1;
		
		for( int i=0; i<=1; i++) {
			resultado2 = (resultado2 * base);
			
		}
		for( int i=0; i<=2; i++) {
			resultado3 = (resultado3 * base);
			
		}
		System.out.println("Base: " + base + ", Cuadrado = " + resultado2 + " Cubo: " + resultado3);		
		
		++base;
		resultado3 = 1;
		resultado2 = 1;
		for(int i=0; i<=1; i++) {
			resultado2 = (resultado2 * base);
		}for( int i=0; i<=2; i++) {
			resultado3 = (resultado3 * base);
		}
		System.out.println("Base: " + base + ", Cuadrado = " + resultado2 + " Cubo: " + resultado3);
		
		++base;
		resultado3 = 1;
		resultado2 = 1;
		for(int i=0; i<=1; i++) {
			resultado2 = (resultado2 * base);
		}for( int i=0; i<=2; i++) {
			resultado3 = (resultado3 * base);
		}
		System.out.println("Base: " + base + ", Cuadrado = " + resultado2 + " Cubo: " + resultado3);
		
		++base;
		resultado3 = 1;
		resultado2 = 1;
		for(int i=0; i<=1; i++) {
			resultado2 = (resultado2 * base);
		}for( int i=0; i<=2; i++) {
			resultado3 = (resultado3 * base);
		}
		System.out.println("Base: " + base + ", Cuadrado = " + resultado2 + " Cubo: " + resultado3);
		
		++base;
		resultado3 = 1;
		resultado2 = 1;
		for(int i=0; i<=1; i++) {
			resultado2 = (resultado2 * base);
		}for( int i=0; i<=2; i++) {
			resultado3 = (resultado3 * base);
		}
		System.out.println("Base: " + base + ", Cuadrado = " + resultado2 + " Cubo: " + resultado3);
		
		++base;
		resultado3 = 1;
		resultado2 = 1;
		for(int i=0; i<=1; i++) {
			resultado2 = (resultado2 * base);
		}for( int i=0; i<=2; i++) {
			resultado3 = (resultado3 * base);
		}
		System.out.println("Base: " + base + ", Cuadrado = " + resultado2 + " Cubo: " + resultado3);
		
	}


}
