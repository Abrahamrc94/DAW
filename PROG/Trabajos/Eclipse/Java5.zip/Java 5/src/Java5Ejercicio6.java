
public class Java5Ejercicio6 {

	public static void main(String[] args) {
		
		int i = 320;
		
		do {
			System.out.println("Solucion: " + i);
			i-=20;
		}while(i>=160);
			
		

	}

}
