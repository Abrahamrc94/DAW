
public class Java5Ejercicio1 {

	public static void main(String[] args) {
		
		int num = 5;
		
		for (int i = 1; i<=20 ; i++) {
			System.out.println("Multiplos de 5 hasta 100= " + num * i);
		}
		

	}

}
