import java.util.Scanner;

public class Java5Ejercicio13 {

	public static void main(String[] args) {
			
		System.out.println("Introduzca 10 numeros: ");
		
		Scanner x = new Scanner(System.in);
		
		int numero = 0;
		
		int negativos = 0;
		int positivos = 0;
		
		
		for(int i=0; i<10; i++) {
			if((numero = x.nextInt()) < 0) {
				negativos++;
			}else {
				positivos++;
			}
		}System.out.println("Positivos: " + positivos + ", Negativos: " + negativos);
		
		

	}

}
