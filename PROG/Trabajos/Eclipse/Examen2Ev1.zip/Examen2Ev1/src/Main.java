import Empleados.*;
/**
 * @author Jose
 * @version 1.2
 */
public class Main {

	/**
	 * 
	 */
	public static void main(String[] args) {

		System.out.println("Trabajo del programador:");
		Programador prog = new Programador();
		prog.setNombre("Luis");
		prog.setEdad(24);
		prog.setCategoria(0);
		prog.setAntigüedad(0);
		prog.setNombreProg(prog.getNombre());
		//prog.cambiar("Luis", 24, 0, 0);
		System.out.println("Sueldo: " + prog.calcularSueldo());
		prog.generaNumero();
		System.out.println(prog.trabaja());
		System.out.println(prog.toString());
		
		System.out.println("\nTrabajo del analista:");
		Analista analista = new Analista();
		analista.setNombre("Ana");
		analista.setEdad(35);
		analista.setCategoria(0);
		analista.setAntigüedad(1);
		analista.setNombreAnalista(analista.getNombre());
		//analista.cambiar("Jose", 21, 0, 1);
		System.out.println("Sueldo: " + analista.calcularSueldo());
		analista.darMes();
		System.out.println(analista.trabaja());
		System.out.println(analista.toString());
		
		System.out.println("\nTrabajo del jefe de proyecto:");
		JefeDeProyecto jefe = new JefeDeProyecto();
		jefe.setNombre("Pedro");
		jefe.setEdad(48);
		jefe.setCategoria(1);
		jefe.setAntigüedad(2);
		jefe.setNombreJefe(jefe.getNombre());
		jefe.setNombreProgramadores(prog.getNombreProg());
		jefe.setNombreAnalistas(analista.getNombreAnalista());
		//jefe.cambiar("Juan", 35, 1, 2);
		System.out.println("Sueldo: " + jefe.calcularSueldo());
		jefe.gestion();
		System.out.println(jefe.trabaja());
		System.out.println(jefe.toString());
		
		System.out.println("\nTrabajo del gerente");
		Gerente gerente = new Gerente();
		gerente.setNombre("Paco");
		gerente.setEdad(61);
		gerente.setCategoria(2);
		gerente.setAntigüedad(2);
		gerente.setNombreGerente(gerente.getNombre());
		//gerente.cambiar("Paco", 87, 2, 2);
		System.out.println("Sueldo: " + gerente.calcularSueldo());
		gerente.dice();
		System.out.println(gerente.trabaja());
		System.out.println(gerente.toString());
		
	}

}
