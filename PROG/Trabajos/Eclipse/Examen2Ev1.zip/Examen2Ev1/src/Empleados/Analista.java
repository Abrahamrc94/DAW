/**
 * 
 */
package Empleados;

import java.util.Scanner;

/**
 * @author Jose
 *
 */
public class Analista extends Trabajador {
	
	private String mes;
	private String nombreAnalista;

	/**
	 * 
	 * @param mes
	 * @param x
	 * 
	 */
	public Analista() {
		
		terminado = false;
	}

	public void setNombreAnalista(String nombreAnalista) {
		this.nombreAnalista = nombreAnalista;
	}
	
	public String getNombreAnalista() {
		return nombreAnalista;
	}
	
	public void darMes() {
		
		System.out.print("Introduzca su mes: ");
		mes = x.nextLine();
		
		if(mes.equals("Enero") || mes.equals("Marzo") || mes.equals("Mayo") || mes.equals("Julio") || mes.equals("Agosto") || mes.equals("Octubre") || mes.equals("Diciembre")) {
			
			for(int i = 1; i <= 31; i++) {
				System.out.print(i + " ");
			}
			terminado = true;
		} else if (mes.equals("Abril") || mes.equals("Junio") || mes.equals("Septiembre") || mes.equals("Noviembre")){
			
			for(int i = 1; i <= 30; i++) {
				System.out.print(i + " ");
			}
			terminado = true;
		} else if(mes.equals("Febrero")) {
			
			System.out.println("Los dias del mes de febrero dependen del año");
		} else {
			
			System.out.println("El mes indicado no existe");
		}
	}

	@Override
	public int trabaja() {
		
		if(terminado == true) {
			return 0;
		}else {
			return 1;
		}
	}

}
