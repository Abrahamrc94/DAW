/**
 * 
 */
package Empleados;
/**
 * @author Jose
 *
 */
public class Gerente extends Trabajador {

	private String nombreGerente;

	/**
	 * 
	 */
	public Gerente() {
		terminado = true;
	}
	
	public String getNombreGerente() {
		return nombreGerente;
	}

	public void setNombreGerente(String nombreGerente) {
		this.nombreGerente = nombreGerente;
	}
	
	public void dice() {
		
		for(int i=0; i<=(Math.random()*100+1); i++) {
			System.out.println("Yo soy el jefe y nunca me equivoco. Si no somos capaces de hacerlo, nos retiramos...");
		}
	}

	@Override
	public int trabaja() {
		
		if(terminado == true) {
			return 0;
		}else {
			return 1;
		}
	}

}
