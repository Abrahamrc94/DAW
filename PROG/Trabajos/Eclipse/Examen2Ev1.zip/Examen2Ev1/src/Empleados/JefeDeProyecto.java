/**
 * 
 */
package Empleados;
import java.util.Scanner;

/**
 * @author Jose
 *
 */
public class JefeDeProyecto extends Trabajador {
	
	private String nombreProgramadores;
	private String nombreAnalistas;

	private String nombreTrabajador;
	private String nombreJefe;

	public JefeDeProyecto() {
		terminado = false;
	}
	
	public String getNombreJefe() {
		return nombreJefe;
	}

	public void setNombreJefe(String nombreJefe) {
		this.nombreJefe = nombreJefe;
	}

	public void setNombreProgramadores(String nombreProgramadores) {
		this.nombreProgramadores = nombreProgramadores;
	}

	public void setNombreAnalistas(String nombreAnalistas) {
		this.nombreAnalistas = nombreAnalistas;
	}
	
	public void gestion() {
		
		do {
			System.out.print("Introduzca nombre de trabajador o Fin para salir: ");
			nombreTrabajador = x.nextLine();
		
			if (nombreTrabajador.equals(nombreProgramadores)) {
				System.out.println(nombreProgramadores + " es programador");
				terminado = true;
			}else if (nombreTrabajador.equals(nombreAnalistas)) {
				System.out.println(nombreAnalistas + " es analista");
				terminado = true;
			}else if (nombreTrabajador.equals("Fin")) {
				break;
			}else {
				System.out.println("Nombre mal introducido, vuelva a introducirlo por favor.");
				terminado = false;
			}
		}while(!nombreTrabajador.equals("Fin"));
		
	}

	@Override
	public int trabaja() {
		if(terminado == true) {
			return 0;
		}else {
			return 1;
		}
	}
	
	

}
