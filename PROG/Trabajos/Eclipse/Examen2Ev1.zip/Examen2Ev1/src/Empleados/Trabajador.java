package Empleados;

import java.util.Scanner;

/**
 * @author Jose
 * 
 */
public abstract class Trabajador {

	protected Scanner x = new Scanner(System.in);
	
	protected boolean terminado;
	
	private String nombre;
	private int edad;
	private int categoria;
	private int antigüedad;
	
	public static final int CAT_EMPLEADO = 0;
	public static final int CAT_ENCARGADO = 1;
	public static final int CAT_DIRECTIVO = 2;
	public static final int ANT_NOVATO = 0;
	public static final int ANT_MADURO = 1;
	public static final int ANT_EXPERTO = 2;
	
	private final double sueldoBase = 607;
	protected double sueldoCategoria;
	protected double sueldoAntigüedad;
	
	/**
	 * 
	 * @param edad
	 * @param nombre
	 * @param categoria
	 * @param antiüedad
	 * @param CAT_EMPLEADO
	 * @param CAT_ENCARGADO
	 * @param CAT_DIRECTIVO
	 * @param ANT_NOVATO
	 * @param ANT_MADURO
	 * @param ANT_EXPERTO
	 * @param terminado
	 * @param sueldoBase
	 * @param sueldoCategoria
	 * @param sueldoAntigüedad
	 * 
	 */
	
	public Trabajador() {
		
	}
	
	public void cambiar(String nombre, int edad, int categoria, int antigüedad) {
		this.nombre = nombre;
		this.edad = edad;
		this.categoria = categoria;
		this.antigüedad = antigüedad;
	}
	
	@Override
	public String toString() {
		return (nombre + " " + edad + " " + categoria + " " + antigüedad);
	}
	
	public abstract int trabaja();
	
	public double calcularSueldo() {
		
		if(categoria == CAT_EMPLEADO) {
			sueldoCategoria = (sueldoBase*1.15);
		}else if(categoria == CAT_ENCARGADO) {
			sueldoCategoria = (sueldoBase*1.35);
		}else if (categoria == CAT_DIRECTIVO) {
			sueldoCategoria = (sueldoBase*1.6);
		}
		
		if(antigüedad == ANT_NOVATO) {
			sueldoAntigüedad = (sueldoCategoria + 150);
		}else if(antigüedad == ANT_MADURO) {
			sueldoAntigüedad = (sueldoCategoria + 300);
		}else if (antigüedad == ANT_EXPERTO) {
			sueldoAntigüedad = (sueldoCategoria + 600);
		}
		
		return sueldoAntigüedad;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

	public int getAntigüedad() {
		return antigüedad;
	}

	public void setAntigüedad(int antigüedad) {
		this.antigüedad = antigüedad;
	}

}
