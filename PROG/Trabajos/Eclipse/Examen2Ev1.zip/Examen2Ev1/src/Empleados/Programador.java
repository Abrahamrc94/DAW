/**
 * 
 */
package Empleados;
import java.util.Scanner;

/**
 * @author Jose
 *
 */
public class Programador extends Trabajador {
	
	
	private int numero;
	private String nombreProg;

	/**
	 * 
	 * @param numero
	 * @param x
	 * 
	 */
	public Programador() {
		terminado = false;
	}

	public void setNombreProg(String nombreProg) {
		this.nombreProg = nombreProg;
	}
	
	public String getNombreProg() {
		return nombreProg;
	}
	
	public void generaNumero() {
		
		System.out.print("Introduzca numero: ");
		numero = x.nextInt();
			
		if(numero <= 100 && numero >= 1) {
			for(int i = 1; i <= numero; i++) {
				System.out.println();
				
				System.out.println(i);
				System.out.println(i * Math.random()*100+1);
				
			}
			terminado = true;
		} else {
			System.out.println("Numero mal introducido");
		}
	}
	
	@Override
	public int trabaja() {
		
		if(terminado == true) {
			return 0;
		}else {
			return 1;
		}
	}
	
	

}
