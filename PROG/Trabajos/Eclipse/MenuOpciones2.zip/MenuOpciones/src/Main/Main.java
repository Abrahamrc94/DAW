/**
 * 
 */
package Main;

import java.util.ArrayList;
import java.util.Scanner;

import Alumnos.Alumno;

/**
 * @author Jose
 *
 */
public class Main {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		String opcion;
		String nombre;
		String apellido;
		String dni;
		String subopcion;
		int pos;
		
		ArrayList<Object> ListaAlumnos = new ArrayList<>();
		Alumno alumno;
		
		
		do {
			System.out.println("Elija la opcion adecuada\nOpcion 1 - añadir alumnos\nOpcion 2 - mostrar alumnos\nOpcion 3 - eliminar alumnos\nOpcion 4 - mostrar alumnos\nOpcion 5 - salir");
			opcion = x.nextLine();
			
			
			if(opcion.equals("1")) {
				System.out.println("Has elegido la opcion 1");
				
				System.out.print("Escriba el nombre del alumno: ");
				nombre = x.nextLine();
				System.out.print("Escriba el apellido del alumno: ");
				apellido = x.nextLine();
				System.out.print("Escriba el dni del alumno: ");
				dni = x.nextLine();
				
				ListaAlumnos.add(alumno = new Alumno(nombre, apellido, dni));
				
				System.out.println("Alumno " + nombre + " " + apellido + " con DNI " + dni + " insertado");
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("2")) {
				System.out.println("Has elegido la opcion 2");
				System.out.println("Elija la posicion del alumno a buscar");
				pos = y.nextInt();
				System.out.println(ListaAlumnos.get(pos).toString());
				
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("3")) {
				System.out.println("Has elegido la opcion 3");
				System.out.println("Elija que alumno quiere eliminar: ");
				pos = x.nextInt();
				
				ListaAlumnos.remove(pos);
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("4")) {
				System.out.println("Has elegido la opcion 4");
				for(int i = 0; i < ListaAlumnos.size(); i++) {
					System.out.println(ListaAlumnos.get(i).toString());
				}
				
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("5")) {
				System.out.println("Saliendo...");
			}
		}while(!opcion.equals("5"));
		
		x.close();
	}
	

}
