import java.util.Scanner;

import maquinaria.Locomotora;
import maquinaria.Tren;
import personal.JefeEstacion;
import personal.Maquinista;
import personal.Mecanico;

public class Main {
	
	public static void main (String args[]) {
		
		Scanner x = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		int vagonesAñadir;
		
		Mecanico mec = new Mecanico();
		Maquinista maq = new Maquinista();
		JefeEstacion jefe = new JefeEstacion();
		Locomotora loc = new Locomotora();
		Tren tren = new Tren();
		
		int numeroTotalVagones = tren.getNumVagones();
		
		System.out.print("Introduzca el nombre de su mecánico: ");
		mec.setNombre(x.nextLine());
		System.out.print("Introduzca el telefono de su mecánico: ");
		mec.setTelefono(x.nextLine());
		System.out.print("Introduzca la especialidad de su mecánico: ");
		mec.setEspecialidad(x.nextLine());
		
		System.out.print("\nIntroduzca el nombre de su maquinista: ");
		maq.setNombre(x.nextLine());
		System.out.print("Introduzca el DNI de su maquinista: ");
		maq.setDni(x.nextLine());
		System.out.print("Introduzca el sueldo de su maquinista: ");
		maq.setSueldo(x.nextDouble());
		System.out.print("Introduzca el rango de su maquinista: ");
		maq.setRango(y.nextLine());
		
		System.out.print("\nIntroduzca el nombre de su jefe de estacion: ");
		jefe.setNombre(y.nextLine());
		System.out.print("Introduzca el DNI de su jefe de estacion: ");
		jefe.setDni(y.nextLine());
		
		System.out.print("\nIntroduzca la matricula de su locomotora: ");
		loc.setMatricula(y.nextLine());
		System.out.print("Introduzca la potencia de su locomotora: ");
		loc.setPotencia(y.nextInt());
		System.out.print("Introduzca el anyo de fabricacion de su locomotora: ");
		loc.setAnyo(y.nextInt());
		
		System.out.print("\nAhora mismo tiene: " + tren.getNumVagones() + ", ¿cuantos quiere añadir?");
		
		do {
			vagonesAñadir = y.nextInt();
		
			if(vagonesAñadir > tren.getVagones()) {
			System.out.println("No puede añadir mas de " + tren.getVagones() + ", por favor vuelva a introducir cuantos quiere");
			
			}else {
			numeroTotalVagones = vagonesAñadir + tren.getNumVagones();
			}
		}while(vagonesAñadir > tren.getVagones());
		
		System.out.println("\nNombre de mecanico: " + mec.getNombre());
		System.out.println("Telefono de mecanico: " + mec.getTelefono());
		System.out.println("Especialidad de mecanico: " + mec.getEspecialidad());
		System.out.println("Nombre de maquinista: " + maq.getNombre());
		System.out.println("DNI de maquinista: " + maq.getDni());
		System.out.println("Sueldo de maquinista: " + maq.getSueldo());
		System.out.println("Rango de maquinista: " + maq.getRango());
		System.out.println("Nombre de jefe de estacion: " + jefe.getNombre());
		System.out.println("DNI de jefe de estacion: " + jefe.getDni());
		System.out.println("Matricula de locomotora: " + loc.getMatricula());
		System.out.println("Potencia de locomotora" + loc.getPotencia());
		System.out.println("Año de fabricacion de locomotora: " + loc.getAnyo());
		System.out.println("Numero de vagones finales: " + numeroTotalVagones);
		
	}
	
	
	



}
