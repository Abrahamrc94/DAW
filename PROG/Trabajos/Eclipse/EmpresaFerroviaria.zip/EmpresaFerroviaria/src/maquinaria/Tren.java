package maquinaria;

import java.util.Scanner;
import personal.Maquinista;

public class Tren {
    private Locomotora locomotora;
    private Vagon vagones[];
    private Maquinista responsable;
    private int numVagones; //n�mero de vagones que forman el tren
    
    Vagon vagon = new Vagon();
    
    public String getLocomotora() {
    	return locomotora.getMatricula();
    }
    
    public void setVagones(Vagon[] vagones_tren) {
    	vagones = vagones_tren;
    }
    
    public int getVagones() {
    	return vagon.getCapacidadMax();
    }
    
    public String getResponsable() {
    	return responsable.getNombre();
    }
    
    public int getNumVagones() {
    	return vagon.getCapacidadActual();
    }
    
//    public Tren(Locomotora locomotora, Maquinista responsable) {
//        this.locomotora = locomotora;
//        this.responsable = responsable;
//        
//        //creamos la tabla de tama�o 5, pero no se crea ning�n objeto de tipo vag�n
//        vagones = new Vagon[5]; 
//        numVagones = 0; //por ahora no hay vagones enganchados al tren
//    }
    
    /* Al ser la clase Vagon no visible por clases externas, ser� la clase Tren la que 
     * se encargue de construir el objeto a partir de los datos que nos pasen. 			*/
    public void enganchaVagon(int capacidadMax, int capacidadActual, String mercancia) {

    	setVagones(vagones);
    	
        if (numVagones >= 5) {
            System.out.println("El tren no admite m�s vagones");
        } else {
            Vagon v = new Vagon ();
            vagones[numVagones] = v; //el vag�n pasado ocupa el �ltimo lugar
            numVagones ++; //ahora tenemos un vag�n m�s enganchado al tren
        }
    }   
}
