package maquinaria;
/*
 * Sin modificador de acceso en la clase (private, public, protected): Visibilidad por defecto
 */
class Vagon {
    private final int capacidadMax = 5;
    private int capacidadActual = 0;
    private String mercancia;
    
    public int getCapacidadMax() {
    	return capacidadMax;
    }
    
    public int getCapacidadActual() {
    	return capacidadActual;
    }
    
    public void setMercancia(String mercancia_vagon) {
    	mercancia = mercancia_vagon;
    }
    
    public String getMercancia() {
    	return mercancia;
    }

//    public Vagon(int capacidadMax, int capacidadActual, String mercancia) {
//        this.capacidadMax = capacidadMax;
//        this.capacidadActual = capacidadActual;
//        this.mercancia = mercancia;
//    }
}
