package maquinaria;

import personal.Mecanico;

public class Locomotora {
	//Atributos con visibilidad por defecto. Solo visible por clases vecinas
	private String matricula;
	private int potencia;
	private int anyoFabricacion;
	private Mecanico mec;
	
	public void setMatricula(String martricula_locomotora) {
		matricula = martricula_locomotora;
	}
	
	public String getMatricula() {
		return matricula;
	}
	
	public void setPotencia(int potencia_locomotora) {
		potencia = potencia_locomotora;
	}
	
	public int getPotencia() {
		return potencia;
	}
	
	public void setAnyo(int anyo_locomotora) {
		anyoFabricacion = anyo_locomotora;
	}
	
	public int getAnyo() {
		return anyoFabricacion;
	}

//	public Locomotora(String matricula, int potencia, int anyoFabricacion, Mecanico mec) {
//		this.matricula = matricula;
//		this.potencia = potencia;
//		this.anyoFabricacion = anyoFabricacion;
//		this.mec = mec;
//	}
}
