package personal;

public class Maquinista {
    private String nombre;
    private String dni;
    private double sueldo;
    private String rango;
    
    public void setNombre(String nombre_maquinista) {
		nombre = nombre_maquinista;
	}
    
    public String getNombre() {
    	return nombre;
    }
    
    public void setDni(String dni_maquinista) {
		dni = dni_maquinista;
	}
    
    public String getDni() {
    	return dni;
    }
    
    public void setSueldo(Double sueldo_maquinista) {
		sueldo = sueldo_maquinista;
	}
    
    public Double getSueldo() {
    	return sueldo;
    }
	
    public void setRango(String rango_maquinista) {
		rango = rango_maquinista;
	}
    
    public String getRango() {
    	return rango;
    }

//    private Maquinista(String nombre, String dni, double sueldo, String rango) {
    	
    	
//        this.nombre = nombre;
//        this.dni = dni;
//        this.sueldo = sueldo;
//        this.rango = rango;
	//}
}
