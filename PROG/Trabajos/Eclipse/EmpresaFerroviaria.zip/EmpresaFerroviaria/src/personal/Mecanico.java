package personal;

import java.util.Scanner;

public class Mecanico {
    private String nombre;
    private String telefono;
    private String especialidad;
    
    Scanner x = new Scanner(System.in);
    
    public void setNombre(String nombre_mecanico) {
    	nombre = nombre_mecanico;
    }
    
    public String getNombre() {
    	return nombre;
    }
    
    public void setTelefono(String telefono_mecanico) {
    	telefono = telefono_mecanico;
    }
    
    public String getTelefono() {
    	return telefono;
    }
    
    public void setEspecialidad(String especialidad_mecanico) {
    	especialidad = especialidad_mecanico;
    }
    
    public String getEspecialidad() {
    	return especialidad;
    }

//    public Mecanico(String nombre, String telefono, String especialidad) {
//        this.nombre = nombre;
//        this.telefono = telefono;
//        this.especialidad = especialidad;
//    }
}
