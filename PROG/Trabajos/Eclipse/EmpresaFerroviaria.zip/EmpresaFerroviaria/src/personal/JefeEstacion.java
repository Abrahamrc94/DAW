package personal;

public class JefeEstacion {
    String nombre;
    String dni;
    
    public void setNombre(String nombre_jefe) {
    	nombre = nombre_jefe;
    }
    
    public String getNombre() {
    	return nombre;
    }
    
    public void setDni(String dni_jefe) {
    	dni = dni_jefe;
    }
    
    public String getDni() {
    	return dni;
    }

//    public JefeEstacion(String nombre, String dni) {
//        this.nombre = nombre;
//        this.dni = dni;
//    }
}
