/**
 * 
 */
package Main;

import java.util.Scanner;

/**
 * @author Jose
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		String opcion;
		String subopcion;
		
		
		do {
			System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nOpcion 5\nfin");
			opcion = x.nextLine();
			
			
			if(opcion.equals("1")) {
				System.out.println("Has elegido la opcion 1");
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("2")) {
				System.out.println("Has elegido la opcion 2");
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("3")) {
				System.out.println("Has elegido la opcion 3");
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("4")) {
				System.out.println("Has elegido la opcion 4");
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("5")) {
				System.out.println("Has elegido la opcion 5");
				do {
					System.out.println("Elija la opcion adecuada\nOpcion 1\nOpcion 2\nOpcion 3\nOpcion 4\nfin");
					subopcion = x.nextLine();
					
					if(subopcion.equals("1")) {
						System.out.println("Has elegido la subopcion 1");
					}else if(subopcion.equals("2")) {
						System.out.println("Has elegido la subopcion 2");
					}else if(subopcion.equals("3")) {
						System.out.println("Has elegido la subopcion 3");
					}else if(subopcion.equals("4")) {
						System.out.println("Has elegido la subopcion 4");
					}
				}while(!subopcion.equals("fin"));
			}else if(opcion.equals("fin")) {
				System.out.println("Saliendo...");
			}
			
		}while(!opcion.equals("fin"));
		
		x.close();
	}
	

}
