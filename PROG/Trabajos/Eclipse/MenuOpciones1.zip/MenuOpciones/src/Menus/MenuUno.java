/*
   Implementa en java un menú de 5 opciones que se esté siempre mostrando al usuario hasta que pulse fin.
   Cada opción, identificada como "Opción1"..."Opción4", "salir", deberá contener otro menú con 4 opciones cada uno, 
   donde la última opción de este submenú será "salir" de este submenú. 

   En todos los casos, por el momento, dentro de cada opción el programa mostrará por consola el mensaje 
   "Has elegido la opción X del menú principal" o "Has elegido la opción Y del submenú de la opción X del menú principal".
 */
package Menus;

import java.util.Scanner;

/**
 * @author estudiante
 *
 */
public class MenuUno {


	
	public MenuUno() {
		
	}
	
	public void menuUno() {
		

	}

}
