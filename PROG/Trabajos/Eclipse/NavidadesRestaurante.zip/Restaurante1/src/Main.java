import Almacenes.Almacen;

public class Main {

	public static void main(String[] args) {
		
		Almacen almacen = new Almacen(4, 4.2);
		
		almacen.calcular();

	}

}
