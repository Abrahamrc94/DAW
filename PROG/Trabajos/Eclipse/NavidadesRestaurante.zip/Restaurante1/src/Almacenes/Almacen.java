package Almacenes;

/**
 * @author Jose
 *
 */
public class Almacen {

	private double calabazas;
	private double garbanzos;
	private double calculo1;
	private double calculo2;
	
	public Almacen(double garbanzos, double calabazas) {
		this.garbanzos = garbanzos;
		this.calabazas = calabazas;
	}

	public void calcular() {
		
		calculo1 = ((this.garbanzos/0.33) + (this.calabazas/0.166));
		calculo2 = calculo1/2;
		
		System.out.println("Tienes para " + (int)calculo2 + " personas");
		
	}
	
}
