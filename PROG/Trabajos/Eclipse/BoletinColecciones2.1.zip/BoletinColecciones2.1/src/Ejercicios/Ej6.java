/*
    6.Implementar la función leeCadena, con el siguiente prototipo: List<Character> leeCadena()
	Dicha función lee una cadena por teclado y nos a devuelve en una lista con un carácter en cada nodo.
 */
package Ejercicios;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @author estudiante
 */
@SuppressWarnings("serial")
public class Ej6 extends ArrayList<Character>{
	
	public Ej6() {
		
	}
	
	public List<Character> leeCadena(FileReader fr, String cadena){
		
		try {
			for(int i = 0; i<cadena.length(); i++) {
				this.add((char) fr.read());
			}
		}catch(Exception e) {
			System.out.println("ERROR");
		}
		
		return this;
	}
}
