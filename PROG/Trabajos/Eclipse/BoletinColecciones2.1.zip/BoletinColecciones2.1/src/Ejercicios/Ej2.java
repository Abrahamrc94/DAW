   /*
	2.Hacer lo mismo que en el ejercicio anterior pero con la intersección, formada por los elementos comunes a los dos 
    conjuntos: Set intersección(Set conjunto1, Set conjunto2)
   */
package Ejercicios;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author Jose
 *
 */
public class Ej2 {

	private TreeSet<Integer>Lista3 = new TreeSet<Integer>();
	
	public Ej2() {
		
	}
	
	@SuppressWarnings("rawtypes")
	public Set interseccion(Set<Integer>conjunto1, Set<Integer>conjunto2) {
		
		for(int i : conjunto1) {
			if(conjunto2.contains(i)) {
				Lista3.add(i);
			}
		}
		
		return Lista3;
	}

}
