package Ejercicios;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;


/**
 * @author estudiante
 *
 */
@SuppressWarnings("serial")
public class Ej8 extends ArrayList<String>{
	
	public Ej8() {
		
	}

	@SuppressWarnings({ "rawtypes" })
	public List clonaLista(BufferedReader br) {
		
		try {
			for(int i = 0; i<5; i++){
				this.add(br.readLine());
			}
		}catch(Exception e) {
			System.out.println("ERROR");
		}
		
		
		return this;
	}
}
