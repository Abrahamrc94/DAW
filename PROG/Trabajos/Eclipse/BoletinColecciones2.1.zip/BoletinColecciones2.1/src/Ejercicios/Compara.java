/**
 * 
 */
package Ejercicios;

import java.util.Comparator;

/**
 * @author estudiante
 *
 */
class Compara implements Comparator<Object>{

	public Compara() {
		
	}

	@Override
	public int compare(Object o1, Object o2) {

		
		return 0;
	}

}