 /*
   3.Diseñar un método que devuelva la diferencia de dos conjuntos (elementos que pertenezcan al primero, pero no al segundo),
   con la sintaxis: Set diferencia(Set conjunto1, Set conjunto2)
 */
package Ejercicios;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author Jose
 *
 */
public class Ej3 {

	private TreeSet<Integer>Lista3 = new TreeSet<Integer>();
	
	public Ej3() {
		
	}
	
	@SuppressWarnings("rawtypes")
	public Set diferencia(Set<Integer>conjunto1, Set<Integer>conjunto2) {
		
		for(int i : conjunto1) {
			if(!conjunto2.contains(i)) {
				Lista3.add(i);
			}
		}
		
		return Lista3;
	}

}
