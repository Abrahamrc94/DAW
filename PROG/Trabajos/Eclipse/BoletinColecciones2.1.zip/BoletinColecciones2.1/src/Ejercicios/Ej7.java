/*	
    7.Implementar la función uneCadenas con el prototipo:
    List<Character> uneCadenas(List<Character> cad1, List<Character> cad2) 
    que devuelve una lista con la concatenación de cad1 y cad2.
*/

package Ejercicios;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @author estudiante
 */
@SuppressWarnings("serial")
public class Ej7 extends ArrayList<Character>{
	
	public Ej7() {
		
	}
	
public List<Character> uneCadenas(FileReader fr, FileReader fr2, String cadena, String cadena1){
		
		try {
			for(int i = 0; i<cadena.length(); i++) {
				this.add((char) fr.read());
			}
			for(int i = 0; i<cadena1.length(); i++) {
				this.add((char) fr2.read());
			}
		}catch(Exception e) {
			System.out.println("ERROR");
		}
		
		return this;
	}

}
