//package Ejercicios;
//
//import java.util.Comparator;
//import java.util.LinkedList;
//
///**
// * @author estudiante
// *
// */
//@SuppressWarnings({ "serial" })
//public class ListaOrdenada<E> extends LinkedList<E> implements Compara<E>{
//	
//	public ListaOrdenada() {
//		super();
//	}
//	
//	public void insertarOrdenado(E elemento) {
//		int contador = 0;
//		boolean insertado = false;
//		
//		if(size()==0) {
//			add(elemento);
//		}else{
//			do {
//				if(this.compare((E) get(contador), elemento) == -1) {
//					contador++;
//					if(contador >= size()) {
//						addLast(elemento);
//						insertado = true;
//					}else {
//						add(contador, elemento);
//						insertado = true;
//					}
//				}else{
//					contador++;
//				}
//			}while(!insertado);
//		}
//		
//	}
//
//}