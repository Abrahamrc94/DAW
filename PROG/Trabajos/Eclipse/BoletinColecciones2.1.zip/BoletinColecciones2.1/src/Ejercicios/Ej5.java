package Ejercicios;

import java.io.BufferedReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @author estudiante
 *
 */
@SuppressWarnings("serial")
public class Ej5 extends ArrayList<String>{
	
	public Ej5() {
		
	}
	
	public List<String> fusion(BufferedReader bf,BufferedReader bf2) {
		
		try {
			for(int i = 0; i < 5; i++) {
				this.add(bf.readLine());
			}
			for(int i = 0; i < 5; i++) {
				this.add(bf2.readLine());
			}
		}catch(Exception e) {
			System.out.println("Error");
		}
		return this;	
	}
}
