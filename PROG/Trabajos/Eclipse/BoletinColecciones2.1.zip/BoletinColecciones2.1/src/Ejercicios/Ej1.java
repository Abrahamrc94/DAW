/**
 * 1.Implementar el método unión de dos conjuntos, que devuelva un nuevo conjunto con todos los elementos que pertenezcan, 
 * al menos, a uno de los dos conjuntos: Set unión(Set conjunto1, Set conjunto2)
 */
package Ejercicios;
import java.util.Set;
import java.util.TreeSet;

/**
 * @author Jose
 *
 */
public class Ej1 {

	private TreeSet<Integer>Lista3 = new TreeSet<Integer>();
	
	public Ej1() {
		
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Set union(Set conjunto1, Set conjunto2) {
		Lista3.addAll(conjunto1);
		Lista3.addAll(conjunto2);
		return Lista3;	
	}

}
