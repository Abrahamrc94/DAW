import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.TreeSet;

import Ejercicios.*;

/**
 * @author Jose
 */
public class Main {
	
	public static void main(String[] args) {
			
		TreeSet<Integer>Lista1 = new TreeSet<Integer>();
		TreeSet<Integer>Lista2 = new TreeSet<Integer>();
		
		//ArrayList<Integer>Lista1A = new ArrayList<Integer>();
		//ArrayList<Integer>Lista2A = new ArrayList<Integer>();
		
		//ArrayList<Character>Lista1AB = new ArrayList<Character>();
		//ArrayList<Character>Lista2AB = new ArrayList<Character>();
		
		//EJ5------
		try {
			
			BufferedWriter bw = new BufferedWriter(new FileWriter("ej5.txt"));
			
			for(int i = 0; i < 5; i++) {
				//Lista1A.add(i);
				bw.write(i + "");
				bw.newLine();
			}bw.close();
		}catch(Exception e) {
			System.out.println("PROBLEMA");
		}
		
		
		try {
		
			BufferedWriter bw2 = new BufferedWriter(new FileWriter("ej52.txt"));
			
			for(int i = 5; i < 10; i++) {
				//Lista2A.add(i);
				bw2.write(i + "");
				bw2.newLine();
			}bw2.close();
		}catch(Exception ex) {
			System.out.println("PROBLEMA");
		}
		
		//EJ6------
		Scanner y = new Scanner(System.in);
		String cadena2 = y.nextLine();
		
		try {
			
			BufferedWriter bw = new BufferedWriter(new FileWriter("ej6.txt"));
			bw.write(cadena2);
			bw.close();
			
		}catch(Exception e2) {
			System.out.println("ERROR");
		}
		
		
		//EJ7------
		Scanner x = new Scanner(System.in);
		String cadena = x.nextLine();
		String cadena1 = x.nextLine();
		
		try {
			
			BufferedWriter bw = new BufferedWriter(new FileWriter("ej71.txt"));
			bw.write(cadena);
			bw.close();
			
		}catch(Exception e2) {
			System.out.println("ERROR");
		}
		
		try {
			
			BufferedWriter bw = new BufferedWriter(new FileWriter("ej72.txt"));
			bw.write(cadena1);
			bw.close();
			
		}catch(Exception e2) {
			System.out.println("ERROR");
		}
		
		
		//EJ8-----
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter("ej8.txt"));
			
			for(int i = 0; i < 5; i++) {
				bw.write((int)(Math.random()*10) + "");
				bw.newLine();
			}bw.close();
		}catch(Exception e) {
			System.out.println("ERROR");
		}
		
		for(int i = 0; i < 10; i++) {
			Lista1.add((int)(Math.random()*10));
			Lista2.add((int)(Math.random()*10));
		}
		
		Ej1 ej1 = new Ej1();
		System.out.println(ej1.union(Lista1, Lista2));
		
		Ej2 ej2 = new Ej2();
		System.out.println(ej2.interseccion(Lista1, Lista2));
		
		Ej3 ej3 = new Ej3();
		System.out.println(ej3.diferencia(Lista1, Lista2));
		
		Ej4 ej4 = new Ej4();
		System.out.println(ej4.incluido(Lista1, Lista2));
		
		try {
			BufferedReader bf = new BufferedReader(new FileReader("ej5.txt"));
			BufferedReader bf2 = new BufferedReader(new FileReader("ej52.txt"));
		
			Ej5 ej5 = new Ej5();
			System.out.println(ej5.fusion(bf, bf2));
			
			bf.close();
			bf2.close();
		}
		catch(Exception e) {
			System.out.println("Error");
		}
		
		try {
			FileReader fr = new FileReader("ej6.txt");
			
			Ej6 ej6 = new Ej6();
			System.out.println(ej6.leeCadena(fr, cadena2));
		}catch(Exception e) {
			System.out.println("ERROR");
		}	
		
//		cadena = x.nextLine();
//		for(char a : cadena.toCharArray()) {
//			Lista1AB.add(a);
//			Lista2AB.add(a);
//		}
		try {
			FileReader fr = new FileReader("ej71.txt");
			FileReader fr2 = new FileReader("ej72.txt");
			
			Ej7 ej7 = new Ej7();
			System.out.println(ej7.uneCadenas(fr, fr2, cadena, cadena1));
		}catch(Exception e) {
			System.out.println("ERROR");
		}
		
		try {
			BufferedReader bf = new BufferedReader(new FileReader("ej8.txt"));
			
			Ej8 ej8 = new Ej8();
			System.out.println(ej8.clonaLista(bf));
		}catch(Exception e) {
			System.out.println("ERROR");
		}
		
		
//		ListaOrdenada ej9 = new ListaOrdenada();
//		for(int i = 0; i < 5; i++) {
//			ej9.insertarOrdenado((int) (Math.random()*10));
//		}
//		System.out.println(ej9);
	
	}

}