import java.util.Scanner;
public class Error {

	public static void main(String[] args) {
		
		//Hacemos un solo Scanner
		Scanner x = new Scanner(System.in);
		
		//Segundo Scanner para solucionar el problema
		//Scanner y = new Scanner(System.in);
		
		String nombre;
		int numero;
		
		//Vereis como en uno de ellos salta un Scanner y pasa al siguiente. Si en ese caso arreglamos solo el Scanner que nos da fallo con el Scanner Y, el fallo va a irse al de abajo suya
		//Seguira haciendo esto hasta el final. Para solucionarlo cambiaremos el Scanner que nos da error y sus siguientes por el otro que he declarado que es el Y. Comento abajo: 
		
		System.out.print("Nombre: ");
		nombre = x.nextLine();
		System.out.println("Numero: ");
		numero = x.nextInt();
		System.out.print("Nombre: ");
		//A mi me salta este Scanner y pasa al siguiente, solo tenemos que cambiar "x.nextLine()" por "y.nextLine()" y sus siguientes igual. Asi se solucionaría
		nombre = x.nextLine();
		System.out.println("Numero: ");
		numero = x.nextInt();
		System.out.print("Nombre: ");
		nombre = x.nextLine();
		System.out.println("Numero: ");
		numero = x.nextInt();
		
		//SI VEIS QUE OS SUCEDE LO MISMO CON EL NUEVO "SCANNER Y" MAS ABAJO, PUES MISMA SOLUCION, DECLARAIS OTRO NUEVO SCANNER Y LISTO.

	}

}
