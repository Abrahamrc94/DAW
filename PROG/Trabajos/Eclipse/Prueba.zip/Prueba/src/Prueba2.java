/**
 * 
 * @author estudiante 
 * @version 8
 */
public class Prueba2 {
	/**
	 * 
	 * @param args
	 * @throws ArrayIndexOutOfBoundsException
	 */
	
	public static void main(String[] args) throws ArrayIndexOutOfBoundsException {
		try {
		final int FILAS = 9;
		
		int[] v = new int [FILAS];
		
		for(int i=0; i<FILAS+1; i++) {
			v[i]= i;
			System.out.printf("% 4d", v[i]);
		}

		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println(" Problema");
			
		}
	}

}
