import java.util.Scanner;

public class Prueba1 {

	public static void main(String[] args) {
		
		//REPRESENTACION DE MATRIZ;

		Scanner x = new Scanner(System.in);
		
		System.out.print("Introduzca numero de filas: ");
		int numero1 = x.nextInt();
		
		System.out.print("Introduzca numero de columnas: ");
		int numero2 = x.nextInt();
		
		System.out.print("Introduzca numero de profundidad: ");
		int numero3 = x.nextInt();
		
		int[][][] v3 = new int[numero3][numero2][numero1];
		
		for(int i=0; i<numero3; i++) {
			for(int j=0; j<numero2; j++) {
				for(int k=0; k<numero1; k++) {
					v3[i][j][k] = i*j*k;
					System.out.printf("% 4d", v3[i][j][k]);
				}System.out.println("");
			}System.out.println("");
		}
		

	}

}
