//Importamos paquete Scanner
import java.util.Scanner;

public class Java9 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y declaramos variables igual a datos por teclado
		System.out.print("Introduzca precio de la manzana este ano: ");
		Scanner preciom = new Scanner(System.in);
		double manzanas = preciom.nextDouble();
		
		System.out.print("Introduzca precio de la pera este ano: ");
		Scanner preciop = new Scanner(System.in);
		double peras = preciop.nextDouble();
		
		System.out.print("Introduzca cuanntos KG de manzanas ha vendido usted el primer trimestre: ");
		Scanner x = new Scanner(System.in);
		double kgmanzanas1 = x.nextDouble();
		
		System.out.print("Introduzca cuantos KG de manzanas ha vendido usted el segundo trimestre: ");
		Scanner y = new Scanner(System.in);
		double kgmanzanas2 = y.nextDouble();
		
		System.out.print("Introduzca cuantos KG de manzanas ha vendido usted el tercer trimestre: ");
		Scanner n = new Scanner(System.in);
		double kgmanzanas3 = n.nextDouble();
		
		System.out.print("Introduzca cuantos KG de manzanas ha vendido usted el cuarto trimestre: ");
		Scanner m = new Scanner(System.in);
		double kgmanzanas4 = m.nextDouble();
		
		System.out.print("Introduzca cuantos KG de peras ha vendido usted el primer trimestre: ");
		Scanner p = new Scanner(System.in);
		double kgperas1 = p.nextDouble();
		
		System.out.print("Introduzca cuantos KG de peras ha vendido usted el segundo trimestre: ");
		Scanner i = new Scanner(System.in);
		double kgperas2 = i.nextDouble();
		
		System.out.print("Introduzca cuantos KG de peras ha vendido usted el tercer trimestre: ");
		Scanner o = new Scanner(System.in);
		double kgperas3 = o.nextDouble();
		
		System.out.print("Introduzca cuantos KG de peras ha vendido usted el cuarto trimestre: ");
		Scanner e = new Scanner(System.in);
		double kgperas4 = e.nextDouble();
		
		//Declaramos variable igual a resultado de una operación
		double resultado;
		resultado = (manzanas * (kgmanzanas1 + kgmanzanas2 + kgmanzanas3 + kgmanzanas4)) + (peras * (kgperas1 + kgperas2 + kgperas3 + kgperas4));
		
		//Imprimimos por pantalla el resultado
		System.out.println("El beneficio ganado es: " + resultado);
		

	}

}
