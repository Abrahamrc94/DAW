//Importamos paquete Scanner
import java.util.Scanner;

public class Java5 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla
		System.out.print("Escriba su primer número: ");
		
		//Introducimos datos por teclado
		Scanner x = new Scanner(System.in);
		
		//Declaramos variable con valor igual a dato por teclado
		int number1 = x.nextInt();
		
		//Imprimimos por pantalla
		System.out.print("Escriba su segundo número: ");
		
		//Introducimos otros datos por teclado
		Scanner y = new Scanner(System.in);
		
		//Declaramos variable con valor igual a dato por teclado
		int number2 = y.nextInt();
		
		//Declaramos variable para resultado de operación
		double resultado = ((double)number1 + (double)number2/2);
		
		//Imprimimos por pantalla resultado
		System.out.println("Su media es: " + resultado);

	}

}
