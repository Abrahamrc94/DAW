//Importamos paquete Scanner
import java.util.Scanner;

public class Java8 {

	public static void main(String[] args) {
		
		//Declaramos variables constantes
		final double MANZANAS = 2.35;
		final double PERAS = 1.95;
		
		//Imprimimos por pantalla e introducimos datos y los recogemos en una variable
		System.out.print("Introduzca cuántos KG de manzanas ha vendido usted el primer trimestre: ");
		Scanner x = new Scanner(System.in);
		double kgmanzanas1 = x.nextDouble();
		
		System.out.print("Introduzca cuántos KG de manzanas ha vendido usted el segundo trimestre: ");
		Scanner y = new Scanner(System.in);
		double kgmanzanas2 = y.nextDouble();
		
		System.out.print("Introduzca cuántos KG de manzanas ha vendido usted el tercer trimestre: ");
		Scanner n = new Scanner(System.in);
		double kgmanzanas3 = n.nextDouble();
		
		System.out.print("Introduzca cuántos KG de manzanas ha vendido usted el cuarto trimestre: ");
		Scanner m = new Scanner(System.in);
		double kgmanzanas4 = m.nextDouble();
		
		System.out.print("Introduzca cuántos KG de peras ha vendido usted el primer trimestre: ");
		Scanner p = new Scanner(System.in);
		double kgperas1 = p.nextDouble();
		
		System.out.print("Introduzca cuántos KG de peras ha vendido usted el segundo trimestre: ");
		Scanner i = new Scanner(System.in);
		double kgperas2 = i.nextDouble();
		
		System.out.print("Introduzca cuántos KG de peras ha vendido usted el tercer trimestre: ");
		Scanner o = new Scanner(System.in);
		double kgperas3 = o.nextDouble();
		
		System.out.print("Introduzca cuántos KG de peras ha vendido usted el cuarto trimestre: ");
		Scanner e = new Scanner(System.in);
		double kgperas4 = e.nextDouble();
		
		//Declaramos variable igual a un resultado de una operación
		double resultado;
		resultado = (MANZANAS * (kgmanzanas1 + kgmanzanas2 + kgmanzanas3 + kgmanzanas4)) + (PERAS * (kgperas1 + kgperas2 + kgperas3 + kgperas4));
		
		//Imprimimos por pantalla el resultado
		System.out.println("El beneficio ganado es: " + resultado);
		

	}

}
