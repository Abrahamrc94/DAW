//Importamos paquete de Scanner
import java.util.Scanner;

public class Java1 {

	public static void main(String[] args) {
		
		//Indicamos que introduzca datos por teclado
		Scanner x = new Scanner(System.in);
		
		//Declaramos double para guardar la entrada de datos
		double number = x.nextDouble();
		
		//Imprimimos por pantalla los datos
		System.out.println(number);

	}

}
