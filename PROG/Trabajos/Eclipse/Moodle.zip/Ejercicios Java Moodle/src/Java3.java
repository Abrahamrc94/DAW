//Importamos el paquete Scanner
import java.util.Scanner;

public class Java3 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla que nos escriba el año actual
		System.out.print("Escriba el año actual: ");
		
		//Indicamos que introduzca datos por teclado
		Scanner x = new Scanner (System.in);
		
		//Declaramos int para guardar la entrada de datos
		int year = x.nextInt();
		
		//Imprimimos por pantalla que nos escriba su fecha de nacimiento
		System.out.print("Escriba su fecha de nacimiento: ");
		
		//Indicamos que introduzca datos por teclado
		Scanner y = new Scanner(System.in);
		
		//Declaramos int para guardar la entrada de datos
		int born = y.nextInt();
		
		//Imprimimos por pantalla los resultados
		System.out.println("Su edad es: " + (year - born));
		

	}

}
