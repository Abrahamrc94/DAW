public class Java4 {

	public static void main(String[] args) {
		
		//Declaramos variable
		short max = 32767;
		
		//Añadimos +1 en variable max
		max++;
		
		//Imprimimos por pantalla el resultado
		System.out.println("Su número es: "+ max);
		
		//Añadimos -1 en variable max
		max--;
		
		//Imprimimos por pantalla el resultado
		System.out.println("Su número es: " + max);
		
		
	}

}
