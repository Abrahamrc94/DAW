//Importamos paquete Scanner
import java.util.Scanner;

public class Java6 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla
		System.out.print("Escriba su primer número: ");
		
		//Introducimos datos por teclado
		Scanner x = new Scanner(System.in);
		
		//Declaramos variable igual a datos por teclado
		double number1 = x.nextDouble();
		
		//Imprimimos por pantalla
		System.out.print("Escriba su primer número: ");
		
		//Introducimos datos por teclado
		Scanner y = new Scanner(System.in);
		
		//Declaramos variable igual a datos por teclado
		double number2 = y.nextDouble();
		
		//Imprimimos por pantalla
		System.out.print("Escriba su primer número: ");
		
		//Introducimos datos por teclado
		Scanner z = new Scanner(System.in);
		
		//Declaramos variable igual a datos por teclado
		double number3 = z.nextDouble();
		
		//Declaramos variable igual a resultado de operación
		double resultado = (number1 + number2 + number3)/2;
		
		//Imprimimos resultado de todo
		System.out.print("Redondeo de su media: " + (int)resultado);

	}

}
