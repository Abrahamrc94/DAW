//Importamos paquete Math y Scanner
import java.lang.Math;
import java.util.Scanner;

public class Java7 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla
		System.out.print("Escriba un número decimal: ");
		
		//Introducimos datos por teclado
		Scanner x = new Scanner(System.in);
		
		//Declaramos variable igual a datos por teclado
		double number = x.nextDouble();
		
		//Imprimimos por pantalla resultado
		System.out.print("El redondeo de su número es: " + Math.round(number));
		
	}

}
