//Importamos paquete Scanner
import java.util.Scanner;

public class Java2 {
	public static void main(String[] args) {
		
		//Imprimimos por pantalla que nos diga la edad actual
		System.out.print("Escriba su edad para calcular su edad el año que viene: ");
		
		//Indicamos que introduzca datos por teclado
		Scanner x = new Scanner(System.in);
		
		//Declaramos int para guardar la entrada de datos
		int age = x.nextInt();
		
		//Imprimimos por pantalla los resultados
		System.out.print("Su edad el próximo año será: ");
		System.out.println(age + 1);
	}

}
