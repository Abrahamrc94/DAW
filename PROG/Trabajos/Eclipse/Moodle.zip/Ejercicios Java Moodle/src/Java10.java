//Importamos paquete Scanner y Math
import java.util.Scanner;
import java.lang.Math;

public class Java10 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla que nos introduzca el número deseado.
		System.out.print("Introduzca el radio a calcular: ");
		
		//Indicamos que introduzca datos por teclado
		Scanner x = new Scanner(System.in);
		
		//Declaramos double para guardar la entrada de datos
		double radio = x.nextDouble();
		
		//Imprimimos por pantalla los resultados
		System.out.print("La longitud es: " + (2 * Math.PI * radio));
		System.out.print("El área es: " + (Math.PI * Math.pow(radio, 2)));
		

	}

}
