import java.util.Scanner;
public class Java4Ejercicio16 {

	public static void main(String[] args) {
		
		int puntos = 0;
		
		
		System.out.println("Contesta a las siguientes preguntas con 'SI' o 'NO'");
		System.out.print("¿Te ha dicho que quiere a otra persona?: ");
		
		Scanner x = new Scanner(System.in);
		String respuesta = x.nextLine();
		
		if(respuesta.equals("SI")) {
			puntos++;
		}
		System.out.print("¿Te ha pegado?: ");
		respuesta = x.nextLine();
		
		if(respuesta.equals("SI")) {
			puntos++;
		}
		System.out.print("¿Te quiere?: ");
		respuesta = x.nextLine();
		
		if(respuesta.equals("NO")) {
			puntos++;
		}
		
		System.out.println("Puntos totales: " + puntos + "/3");
		
		if(puntos >= 2) {
			System.out.print("INFIEL!");
		} else {
			System.out.print("FIEL!");
		}
	}

}