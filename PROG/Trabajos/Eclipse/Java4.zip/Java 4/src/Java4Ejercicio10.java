import java.util.Scanner;

public class Java4Ejercicio10 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca dia de nacimiento: ");
		Scanner x = new Scanner(System.in);
		int dia = x.nextInt();
		
		System.out.print("Introduzca mes de nacimiento: ");
		Scanner y = new Scanner(System.in);
		String mes = y.nextLine();
		
		if ((dia >= 21 && dia <= 31 && mes.equals("Marzo")) || (dia >= 1 && dia <= 20 && mes.equals("Abril"))) {
			System.out.println("Su horoscopo es Aries");
		} else if ((dia >= 21 && dia <= 31 && mes.equals("Abril")) || (dia >= 1 && dia <= 21 && mes.equals("Mayo"))){
			System.out.println("Su horoscopo es Tauro");
		} else if ((dia >= 22 && dia <= 31 && mes.equals("Mayo")) || (dia >= 1 && dia <= 21 && mes.equals("Junio"))){
			System.out.println("Su horoscopo es Geminis");
		} else if ((dia >= 22 && dia <= 31 && mes.equals("Junio")) || (dia >= 1 && dia <= 22 && mes.equals("Julio"))){
			System.out.println("Su horoscopo es Cancer");
		} else if ((dia >= 23 && dia <= 31 && mes.equals("Julio")) || (dia >= 1 && dia <= 22 && mes.equals("Agosto"))){
			System.out.println("Su horoscopo es Leo");
		} else if ((dia >= 23 && dia <= 31 && mes.equals("Agosto")) || (dia >= 1 && dia <= 22 && mes.equals("Septiembre"))){
			System.out.println("Su horoscopo es Virgo");
		} else if ((dia >= 23 && dia <= 31 && mes.equals("Septiembre")) || (dia >= 1 && dia <= 22 && mes.equals("Octubre"))){
			System.out.println("Su horoscopo es Libra");
		} else if ((dia >= 23 && dia <= 31 && mes.equals("Octubre")) || (dia >= 1 && dia <= 22 && mes.equals("Noviembre"))){
			System.out.println("Su horoscopo es Escorpio");
		} else if ((dia >= 23 && dia <= 31 && mes.equals("Noviembre")) || (dia >= 1 && dia <= 21 && mes.equals("Diciembre"))){
			System.out.println("Su horoscopo es Sagitario");
		} else if ((dia >= 22 && dia <= 31 && mes.equals("Diciembre")) || (dia >= 1 && dia <= 20 && mes.equals("Enero"))){
			System.out.println("Su horoscopo es Capricornio");
		} else if ((dia >= 21 && dia <= 31 && mes.equals("Enero")) || (dia >= 1 && dia <= 19 && mes.equals("Febrero"))){
			System.out.println("Su horoscopo es Acuario");
		} else if ((dia >= 20 && dia <= 31 && mes.equals("Febrero")) || (dia >= 1 && dia <= 20 && mes.equals("Marzo"))){
			System.out.println("Su horoscopo es Piscis");
		} else {
			System.out.println("Introduzca de nuevo");
		}

	}

}
