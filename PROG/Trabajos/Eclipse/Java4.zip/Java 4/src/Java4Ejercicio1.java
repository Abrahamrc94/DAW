import java.util.Scanner;
public class Java4Ejercicio1 {

	public static void main(String[] args) {
		System.out.print("Escriba su día: ");
		
		Scanner x = new Scanner(System.in);
		String respuesta = x.nextLine();
		
		String horario = null;
		
		
		if(respuesta.equals("Lunes")) {
			System.out.println("Lenguaje de Marcas");
		}	
		if(respuesta.equals("Martes")) {
			System.out.println("Base de Datos");
		}
		if(respuesta.equals("Miercoles")) {
			System.out.println("Lenguaje de Marcas");
		}
		if(respuesta.equals("Jueves")) {
			System.out.println("Base de Datos");
		}
		if(respuesta.equals("Viernes")) {
			System.out.println("Base de Datos");
		}
		
		
		/*switch (respuesta) {
		
			case "Lunes":
				horario = "Lenguaje de Marcas";
				break;
			
			case "Martes":
				horario = "Base de Datos";
				break;
			case "Miercoles":
				horario = "Lenguaje de Marcas";
				break;
			case "Jueves":
				horario = "Base de Datos";
				break;
			case "Viernes":
				horario = "Base de Datos";
				break;
				
		}*/
		
		System.out.print("Dia " + respuesta + ": " + horario);
	

	}
}