import java.util.Scanner;
public class Java4Ejercicio20 {

	public static void main(String[] args) {
		System.out.print("Escriba su numero: ");
		Scanner x = new Scanner(System.in);
		int numero = x.nextInt();
		
		int numerofinal = numero%10;
		
		if(numero >=10 && numero < 100) {
			if(numerofinal == (numero/10)) {
				System.out.println("Capicua");
			}else {
				System.out.println("No es capicua");
			}
		}else if(numero >= 100 && numero < 1000) {
			if(numerofinal == (numero/100)) {
				System.out.println("Capicua");
			}else {
				System.out.println("No es capicua");
			}
		}else if(numero >= 1000 && numero < 10000) {
			if(numerofinal == (numero/1000) && ((numero/100)%10) == ((numero/10)%10)) {
				System.out.println("Capicua");
			}else {
				System.out.println("No es capicua");
			}
		}else if (numero >= 10000 && numero < 100000) {
			if(numerofinal == (numero/10000) && ((numero/1000)%10) == ((numero/10)%10)) {
				System.out.println("Capicua");
			}else {
				System.out.println("No es capicua");
			}
		}else {
			System.out.println("Escriba bien su numero");
		}

	}

}
