import java.util.Scanner;
public class Java4Ejercicio14 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca un numero: ");
		Scanner x = new Scanner(System.in);
		int numero = x.nextInt();
		
		int calculo1 = numero%2;
		int calculo2 = numero%5;
		
		if(calculo1 == 0) {
			System.out.println("Es par");
		}else {
			System.out.println("Es impar");
		}
		
		if(calculo2 == 0) {
			System.out.print("Divisible entre 5");
		}else {
			System.out.println("No es divisible entre 5");
		}

	}

}
