import java.util.Scanner;
public class Java4Ejercicio4 {

	public static void main(String[] args) {
		
		System.out.print("Escriba sus horas trabajadas esta semana: ");
		
		Scanner x = new Scanner(System.in);
		int horas = x.nextInt();
		
		if (horas <= 40) {
			System.out.println("Ha ganado esta semana: " + (horas * 12) + "€");
		}
		
		if (horas >= 41) {
			System.out.println("Ha ganado esta semana: " + ((40 * 12) + ((horas - 40) * 16)));
		}

	}

}
