import java.util.Scanner;

public class Java4Ejercicio15 {

	public static void main(String[] args) {
		System.out.println("Escriba como quiere usted que aparezca la pirámide: abajo, arriba, derecha, izquierda");
		Scanner x = new Scanner(System.in);
		String orientacion = x.nextLine();
		
		String tab = " ";
		
		if(orientacion.equals("arriba")) {
			System.out.println(tab + tab + "*" + tab + tab);
			System.out.println(tab + "*" + "*" + "*" + tab);
			System.out.println("*" + "*" + "*" + "*" + "*");
		}else if (orientacion.equals("abajo")) {
			System.out.println("*" + "*" + "*" + "*" + "*");
			System.out.println(tab + "*" + "*" + "*" + tab);
			System.out.println(tab + tab + "*" + tab + tab);
		}else if(orientacion.equals("derecha")) {
			System.out.println("*" + tab + tab);
			System.out.println("*" + "*" + tab);
			System.out.println("*" + "*" + "*");
			System.out.println("*" + "*" + tab);
			System.out.println("*" + tab + tab);
		}else if(orientacion.equals("izquierda")) {
			System.out.println(tab + tab + "*");
			System.out.println(tab + "*" + "*");
			System.out.println("*" + "*" + "*");
			System.out.println(tab + "*" + "*");
			System.out.println(tab + tab + "*");
		}else {
			System.out.println("Vuelva a escribirlo");
		}

	}

}
