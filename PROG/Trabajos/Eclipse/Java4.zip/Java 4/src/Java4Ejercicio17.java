import java.util.Scanner;
public class Java4Ejercicio17 {

	public static void main(String[] args) {
		System.out.print("Introduzca un numero entero: ");
		Scanner x = new Scanner(System.in);
		int numero = x.nextInt();
		
		System.out.println("El ultimo numero es: " + numero%10);
	}

}
