import java.util.Scanner;
public class Java4Ejercicio11 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca hora: ");
		Scanner x = new Scanner(System.in);
		int hora = x.nextInt();
		
		System.out.print("Introduzca minutos: ");
		Scanner y = new Scanner(System.in);
		int minutos = y.nextInt();
		
		int calculohora = hora * 3600;
		int calculominutos = minutos * 60;
		
		int calculosegundos = calculohora + calculominutos;
		
		int medianoche = 24 * 3600;
		
		int total = medianoche - calculosegundos;
		
		System.out.print("Faltan " + total + " segundos para media noche");
	}

}
