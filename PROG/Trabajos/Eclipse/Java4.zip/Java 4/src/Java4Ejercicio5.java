import java.util.Scanner;
public class Java4Ejercicio5 {

	public static void main(String[] args) {
		
		System.out.print("Escriba valor para a: ");
		Scanner a = new Scanner(System.in);
		double valorA = a.nextDouble();
		
		System.out.print("Escriba valor para b: ");
		Scanner b = new Scanner(System.in);
		double valorB = b.nextDouble();
		
		System.out.println("Su resultado es: " + (0 - valorB)/valorA );

	}

}
