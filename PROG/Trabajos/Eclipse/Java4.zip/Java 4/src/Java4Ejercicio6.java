import java.lang.Math;
import java.util.Scanner;
public class Java4Ejercicio6 {

	public static void main(String[] args) {
		
		System.out.print("Escriba altura por favor: ");
		Scanner h = new Scanner(System.in);
		double altura = h.nextDouble();
		
		final double G = 9.81;
		
		System.out.println("El objeto tardará en caer: " + (Math.sqrt((2*altura)/G)));

	}

}
