import java.util.Scanner;
public class Java4Ejercicio7 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca primera nota: ");
		Scanner x = new Scanner(System.in);
		double primeranota = x.nextDouble();
		
		System.out.print("Introduzca primera nota: ");
		Scanner z = new Scanner(System.in);
		double segundanota = z.nextDouble();
		
		System.out.print("Introduzca primera nota: ");
		Scanner y = new Scanner(System.in);
		double terceranota = y.nextDouble();
		
		System.out.print("Su media es: " + ((primeranota + segundanota + terceranota)/3));

	}

}
