import java.util.Scanner;
public class Java4Ejercicio13 {

	public static void main(String[] args) {
		System.out.print("Introduza primer número entero: ");
		Scanner x = new Scanner(System.in);
		int primernumero = x.nextInt();
		
		System.out.print("Introduza segundo número entero: ");
		Scanner y = new Scanner(System.in);
		int segundonumero = y.nextInt();
		
		System.out.print("Introduza tercero número entero: ");
		Scanner z = new Scanner(System.in);
		int tercernumero = z.nextInt();
		
		
		
		if((primernumero > segundonumero && primernumero > tercernumero) && (segundonumero > tercernumero)) {
			System.out.println("Ordenados quedarían: " + primernumero + ", " + segundonumero + ", " + tercernumero);
		} else if((segundonumero > primernumero && segundonumero > tercernumero) && (primernumero > tercernumero)) {
			System.out.println("Ordenados quedarían: " + segundonumero + ", " + primernumero + ", " + tercernumero);
		} else if((primernumero > segundonumero && primernumero > tercernumero) && (segundonumero < tercernumero)) {
			System.out.println("Ordenados quedarían: " + primernumero + ", " + tercernumero + ", " + segundonumero);
		} else if((segundonumero > primernumero && segundonumero > tercernumero) && (primernumero < tercernumero)) {
			System.out.println("Ordenados quedarían: " + segundonumero + ", " + tercernumero + ", " + primernumero);
		} else if((tercernumero > primernumero && tercernumero > segundonumero) && (primernumero > segundonumero)) {
			System.out.println("Ordenados quedarían: " + tercernumero + ", " + primernumero + ", " + segundonumero);
		} else if((tercernumero > primernumero && tercernumero > segundonumero) && (primernumero < tercernumero)) {
			System.out.println("Ordenados quedarían: " + tercernumero + ", " + segundonumero + ", " + primernumero);
		}

	}

}
