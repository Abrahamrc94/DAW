import java.util.Scanner;
public class Java4Ejercicio8 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca primera nota: ");
		Scanner x = new Scanner(System.in);
		double primeranota = x.nextDouble();
		
		System.out.print("Introduzca primera nota: ");
		Scanner z = new Scanner(System.in);
		double segundanota = z.nextDouble();
		
		System.out.print("Introduzca primera nota: ");
		Scanner y = new Scanner(System.in);
		double terceranota = y.nextDouble();
		
		double media = (primeranota + segundanota + terceranota)/3;
		
		if(media >= 0 && media < 5) {
			System.out.println("Insuficiente");
		} else if (media >= 5 && media < 6) {
			System.out.println("Suficiente");
		} else if (media >= 6 && media < 8) {
			System.out.println("Bien");
		} else if (media >= 8 && media < 9) {
			System.out.print("Notable");
		} else if (media >= 9 && media <= 10) {
			System.out.println("Sobresaliente");
		} else {
			System.out.println("Introduzca notas entre 0 y 10 por favor");
		}		
	}

}
