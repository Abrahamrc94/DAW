//Importamos paquetes
import java.util.Scanner;
import java.lang.Math;

public class Java4Ejercicio9 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y guardamos en variable
		System.out.print("Introduzca valor para 'a': ");
		Scanner x = new Scanner(System.in);
		double valorA = x.nextDouble();
		
		System.out.print("Introduzca valor para 'b': ");
		Scanner y = new Scanner(System.in);
		double valorB = y.nextDouble();
		
		System.out.print("Introduzca valor para 'c': ");
		Scanner z = new Scanner(System.in);
		double valorC = z.nextDouble();
		
		double raiz =  (Math.pow(valorB, 2)) - (4*valorA*valorC);
		
		if(raiz < 0) {
			System.out.println("Raiz negativa, sin solucion");
		}else if (raiz == 0){
			System.out.println("Su resultado de x es: " + (-valorB + Math.sqrt(raiz))/(2 * valorA));
		}else {
		System.out.println("Su resultado en suma de x es: " + (-valorB + Math.sqrt(raiz))/(2 * valorA));
		System.out.println("Su resultado en resta de x es: " + (-valorB - Math.sqrt(raiz))/(2 * valorA));
		}
	}

}