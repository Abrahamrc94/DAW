import java.util.Scanner;
public class Java4Ejercicio19 {

	public static void main(String[] args) {
		System.out.print("Introduzca un numero entero: ");
		Scanner x = new Scanner(System.in);
		int numero = x.nextInt();
		
		if((numero >= 0 && numero < 10) || (numero <= 0 && numero > -10)){
			System.out.println("El numero tiene 1 digito");
		}else if((numero >= 10 && numero < 100) || (numero <= 10 && numero > -100)) {
			System.out.println("El numero tiene 2 digitos");
		}else if((numero >= 100 && numero < 1000) || (numero <= 100 && numero > -1000)) {
			System.out.println("El numero tiene 3 digitos");
		}else if((numero >= 1000 && numero < 10000) || (numero <= 1000 && numero > -10000)) {
			System.out.println("El numero tiene 4 digitos");
		}else if((numero >= 10000 && numero < 100000) || (numero <= 10000 && numero > -100000)) {
			System.out.println("El numero tiene 5 digitos");
		}else {
			System.out.println("Vuelva a escribir bien su numero de entre 1-5 digitos");
		}
	}

}
