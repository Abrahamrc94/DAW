import java.util.Scanner;
public class Java4Ejercicio3 {

	public static void main(String[] args) {
		
		System.out.print("Escriba un numero en relacion a la semana: ");
		
		Scanner x = new Scanner(System.in);
		int number = x.nextInt();
		
		if (number == 1) {
			System.out.println("Lunes");
		} else if (number == 2){
			System.out.println("Martes");
		} else if (number == 3) {
			System.out.println("Miercoles");
		} else if (number == 4) {
			System.out.println("Jueves");
		} else if (number == 5) {
			System.out.println("Viernes");
		} else if (number == 6) {
			System.out.println("Sabado");
		} else if (number == 7) {
			System.out.println("Domingo");
		} else {
			System.out.println("Vuelva a escribir su numero");
		}
		
		

	}

}
