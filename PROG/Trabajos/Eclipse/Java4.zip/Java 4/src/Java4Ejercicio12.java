import java.util.Scanner;
public class Java4Ejercicio12 {

	public static void main(String[] args) {
		
		int puntos = 0;
		
		
		
		System.out.println("Contesta a las siguientes preguntas con 'SI' o 'NO'");
		System.out.print("¿Para introducir datos a un código, hace falta usar Scanner?: ");
		
		Scanner x = new Scanner(System.in);
		String respuesta = x.nextLine();
		
		if(respuesta.equals("SI")) {
			puntos++;
		}
		System.out.print("¿Para Oracle usamos una maquina virtual?: ");
		
		
		respuesta = x.nextLine();
		
		if(respuesta.equals("SI")) {
			puntos++;
		}
		System.out.print("¿GitHub es un repositorio online?: ");
		
		respuesta = x.nextLine();
		
		if(respuesta.equals("SI")) {
			puntos++;
		}
		
		System.out.println("Puntos totales: " + puntos + "/3");
		
		if(puntos >= 2) {
			System.out.print("APROBADO!");
		} else {
			System.out.print("SUSPENSO!");
		}
	}

}
