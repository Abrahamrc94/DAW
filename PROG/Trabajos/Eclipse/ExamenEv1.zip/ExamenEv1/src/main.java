import almacen.Almacen;

/**
 * @author Jose
 *
 */
public class main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Almacen almacen = new Almacen();
		
		System.out.println("Agrega productos");
		almacen.agregarProducto();
		
		System.out.println("Calcula Precios");
		almacen.agregarProducto();
		
		System.out.println("Mostrar informacion");
		almacen.mostrarInformacion();
		
		System.out.println("Eliminar productos");
		almacen.eliminarProductos();
		

	}

}
