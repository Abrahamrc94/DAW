package almacen;
import java.util.Scanner;

import Productos.*;
/**
 * @author Jose
 *
 */
public class Almacen {

	//Estanteria, estantes
	 private Producto [][] estanteria = new Producto [2][3];
	 private Scanner x = new Scanner(System.in);
	 private Scanner y = new Scanner(System.in);
	 private int elegir;
	 
	 double precioTotal;
	 
	 AguaMineral agua = new AguaMineral(5, 1.5, "Bezoya", "Montaña");
	 BebidaAzucarada azucar = new BebidaAzucarada(7, 3.5, "Cocacola", false);
	
	public Almacen() {
		
	}
	
	public void calcularPrecio() {
			
	}
	
	public void agregarProducto() {
		
		for (int i = 0; i < 3; i++) {
			for (int z = 0; z < 5; z++) {
				System.out.print("Que quiere añadir, 1.Agua, 2.Azucarada");
				elegir = x.nextInt();
				if(elegir == 1) {
					estanteria[i][z] = agua;
				}else if(elegir == 2) {
					estanteria [i][z] = azucar;
				}
			}
			
		}
		
	}
	
	public void mostrarInformacion() {
		
		for (int i = 0; i < 3; i++) {
			for (int z = 0; z < 5; z++) {
				System.out.println(estanteria [i][z]); 
			}
		}
			
	}
	
	public void eliminarProductos() {		
		
		System.out.println("Seleccione estanteria y estante que quiere eliminar");
		
		int estant = x.nextInt();
		int estante = y.nextInt();
		
		estanteria [estant][estante] = null;
		
		
	}
	
	
}
