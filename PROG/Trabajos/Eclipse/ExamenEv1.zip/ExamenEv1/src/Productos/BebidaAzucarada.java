package Productos;

/**
 * @author jose
 *
 */
public class BebidaAzucarada extends Producto {

	private boolean descuento;
	
	public BebidaAzucarada(int cant_litros, double precio, String marca, boolean descuento) {
		this.cant_litros = cant_litros;
		this.marca = marca;
		this.precio = precio;
		this.descuento = descuento;
	}
	
	public void descuento() {
		if(descuento == true) {
			this.precio = (precio * 0.9);
		}else {
			this.precio = precio;
		}
	}

}
