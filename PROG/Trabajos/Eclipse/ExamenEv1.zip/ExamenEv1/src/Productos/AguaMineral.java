package Productos;
import java.util.Scanner;

/**
 * @author jose
 *
 */
public class AguaMineral extends Producto {

	private String origen;
	
	public AguaMineral(int cant_litros, double precio, String marca, String origen) {
		id++;

	}


	public String toString() {
		return ("Litros: " + cant_litros + " Precio: " + precio + " Marca: " + marca + " Origen: " + origen);
	}
	

}
