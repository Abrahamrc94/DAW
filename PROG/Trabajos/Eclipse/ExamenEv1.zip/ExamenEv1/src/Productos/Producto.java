/**
 * 
 */
package Productos;

/**
 * @author Jose
 *
 */
public class Producto {

	protected int id = 1;
	protected int cant_litros;
	protected double precio;
	protected String marca;
	
	public Producto() {
		
	}
}
