public class CuentaCorriente {
	
	//Atributos
	private double saldo;
	private double limite_descubierto;
	private String nombre;
	private String dni;

	
	//Clase constructora.
	public CuentaCorriente(String nombre, String dni) {
		this.nombre = nombre;
		this.dni = dni;
		limite_descubierto = -50;

	}
	
	public CuentaCorriente(double saldo) {
		this.saldo = saldo;
		limite_descubierto = 0.0;
	}
	
	public CuentaCorriente(double saldo, double limite_descubierto, String dni) {
		this.saldo = saldo;
		this.limite_descubierto = limite_descubierto;
		this.dni = dni;
	}
	
	//Setter de sacar dinero.
	public void sacarDinero(double saldoSacar) {
		
		if(saldo - saldoSacar >= limite_descubierto) {
		saldo = saldo - saldoSacar;
		}else {
		System.out.println("No puede sacar esa cantidad, su saldo es de " + saldo + " euros. Su limite de descubierto es " + limite_descubierto + " euros");
		}
	}
	
	//Setter de ingresar dinero.
	public void ingresarDinero(double saldoIngresar) {
		saldo = saldo + saldoIngresar;
	}
	
	//Getter toString de toda información.
	public String toString() {
		return ("\nNombre: " + nombre + "\nDNI: " + dni + "\nSaldo: " + saldo);
	}

}