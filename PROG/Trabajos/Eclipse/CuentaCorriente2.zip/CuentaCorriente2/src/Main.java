import java.util.Scanner;
/**
 * @author jose
 *
 */
public class Main {

	public static void main(String[] args) {
		
		int Elegir;
		String nombre;
		String dni;
		
		double saldo;
		double limite;
		
		Scanner x  = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		System.out.println("Crea una cuenta, elige una de las opciones:\n1 para introducir nombre y DNI\n2 para introducir solo saldo\n3 para introducir saldo, limite de descubierto y DNI ");
		System.out.print("Opcion ");
		Elegir = x.nextInt();
		
		if(Elegir  == 1) {
			
			System.out.print("Introduzca nombre: ");
			nombre = y.nextLine();
			System.out.print("Introduzca DNI: ");
			dni = y.nextLine();
			CuentaCorriente cc = new CuentaCorriente(nombre, dni);
			System.out.print("Sacar dinero: ");
			cc.sacarDinero(x.nextDouble());	
			System.out.print("Ingresar dinero: ");
			cc.ingresarDinero(x.nextDouble());
			System.out.println("Datos de su cuenta corriente: " + cc.toString());
		}else if(Elegir == 2) {
			System.out.print("Introduzca saldo: ");
			saldo = x.nextDouble();
			CuentaCorriente cc2 = new CuentaCorriente(saldo);
			System.out.println("Datos de su cuenta corriente: " + saldo + " euros");
		}else if(Elegir == 3) {
			System.out.print("Introduzca saldo: ");
			saldo = x.nextDouble();
			System.out.print("Introduzca limite de descubierto: ");
			limite = x.nextDouble();
			System.out.print("Introduzca DNI: ");
			dni = y.nextLine();
			CuentaCorriente cc3 = new CuentaCorriente(saldo, limite, dni);
			System.out.println("Datos de su cuenta corriente: " + saldo + " euros, " + limite + " limite de descubierto, DNI " + dni);
		}else {
			System.out.println("Opcion equivocada.");
		}

	}

}