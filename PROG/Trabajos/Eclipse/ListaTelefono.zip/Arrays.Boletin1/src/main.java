import Persona.CListaTlfnos;
import Persona.CPersona;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		CListaTlfnos listaTfnos = new CListaTlfnos();
		listaTfnos.a�adir(new CPersona("Juan", "Brenes", 123456));
		
		System.out.println(listaTfnos.buscar(123456));
		
		
	}

}
