package Persona;

/**
 * @author estudiante
 *
 */
public class CListaTlfnos {
	
	private int nElementos;
	private CPersona[] ListaTlfnos = new CPersona[nElementos];
	
	public CListaTlfnos() {
		
		nElementos = 0;
		ListaTlfnos = new CPersona[nElementos];
	}
	
	public void a�adir(CPersona persona) {
		
		nElementos = nElementos + 1;
		
		CPersona[] laux = new CPersona[nElementos];
		
		for(int i = 0; i < ListaTlfnos.length; i++) {
			
			laux[i] = ListaTlfnos[i];
		}
		
		laux[nElementos - 1] = persona;
		ListaTlfnos = laux;
	}
	
	public int buscar(long tel) {
		
		boolean encontrado = false;
		
		//System.out.println(ListaTlfnos.length);
		
		for (int i = 0; i < ListaTlfnos.length && !encontrado; i++) {
			if(ListaTlfnos[i].obtenerTelefono() == tel){
				encontrado = true;
			}
			
		}
		if(encontrado == false) {
			return(0);
		}else {
			return(1);
		}
		
	}


}
