//Importamos paquetes
import java.util.Scanner;
import java.lang.Math;

public class Java5 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y guardamos en variable
		System.out.print("Introduzca valor para 'a': ");
		Scanner x = new Scanner(System.in);
		double valora = x.nextDouble();
		
		System.out.print("Introduzca valor para 'b': ");
		Scanner y = new Scanner(System.in);
		double valorb = y.nextDouble();
		
		System.out.print("Introduzca valor para 'c': ");
		Scanner z = new Scanner(System.in);
		double valorc = z.nextDouble();
		
		System.out.print("Introduzca valor para 'x': ");
		Scanner p = new Scanner(System.in);
		double valorx = p.nextDouble();
		
		//Calculamos el resultado de la operación del problema y lo guardamos en una variable
		double valorY = (valora * Math.pow(valorx, 2) + (valorb * valorx) + (valorc));
		
		//Imprimimos por pantalla los resultados
		System.out.print("Valor para 'y'= " + valorY);

	}

}
