//Importamos paquete Scanner
import java.util.Scanner;

public class Java7 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y lo guardamos en una variable.
		System.out.print("Introduzca distancia en milímetros: ");
		Scanner x = new Scanner(System.in);
		double mm = x.nextDouble();
		
		System.out.print("Introduzca distancia en centímetros: ");
		Scanner y = new Scanner(System.in);
		double cm = y.nextDouble();
		
		System.out.print("Introduzca distancia en metros: ");
		Scanner z = new Scanner(System.in);
		double m = z.nextDouble();
		
		//Calculamos el total
		double total = ((mm * 10) + (cm) + (m/100));
		
		//Imprimimos el total en pantalla
		System.out.print("Su medida en centímetros es: " + total);
		

	}

}
