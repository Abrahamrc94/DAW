import java.util.Scanner;

public class Java8 {

	public static void main(String[] args) {
		
		System.out.print("Introduzca número de hormigas capturadas: ");
		Scanner x = new Scanner(System.in);
		int hormigas = x.nextInt();
		int patashormigas = hormigas * 6;
		
		System.out.print("Introduzca número de arañas capturadas: ");
		Scanner y = new Scanner(System.in);
		int arañas = x.nextInt();
		int patasarañas = arañas * 8;
		
		System.out.print("Introduzca número de cochinillas capturadas: ");
		Scanner z = new Scanner(System.in);
		int cochinillas = x.nextInt();
		int patascochinillas = cochinillas * 14;
		
		System.out.println("Número de patas de hormigas almacenadas: " + patashormigas);
		System.out.println("Número de patas de arañas almacenadas: " + patasarañas);
		System.out.println("Número de patas de cochinillas almacenadas: " + patascochinillas);

	}

}
