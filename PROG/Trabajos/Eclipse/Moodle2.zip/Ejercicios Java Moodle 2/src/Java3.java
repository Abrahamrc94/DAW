//Importamos paquete Scanner
import java.util.Scanner;

public class Java3 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y declaramos variable igual a datos por teclado
		System.out.print("Introduzca su número entero: ");
		Scanner x = new Scanner(System.in);
		int n = x.nextInt();
		
		System.out.print("Introduzca su número 2 entero: ");
		Scanner y = new Scanner(System.in);
		int m = y.nextInt();
		
		//Declaramos variable igual a resto
		int resto = n%m;
		
		//Introducimos condicional
		if(resto == 0)

			System.out.println("Es múltiplo de " + m);
			
		else
			System.out.println("Debe sumarle " + (m - resto));

	}

}
