//Diseñar una aplicación que solicite al usuario que introduzca una cantidad de segundos. 
//La aplicación debe mostrar horas, minutos y segundos que hay en el número de segundos introducidos por el usuario.
//Importamos paquetes
import java.util.Scanner;

public class Java6 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado,los guardamos en variable y calculamos.
		System.out.print("Introduzca segundos a calcular en horas, minutos y segundos: ");
		Scanner x = new Scanner(System.in);
		double seg = x.nextInt();
		
		double calculohora = (seg / 3600);		
		int hora = (int) calculohora;
		
		double calculomin = (calculohora - hora) * 60;
		int min = (int)calculomin;
		
		double calculoseg = ((calculomin-min)*60);
		int segundos = (int)calculoseg;
		
		//Imprimimos el resultado por pantalla
		System.out.print("Horas: " + hora + ", Minutos: " + min + ", Segundos: " + segundos);

	}

}
