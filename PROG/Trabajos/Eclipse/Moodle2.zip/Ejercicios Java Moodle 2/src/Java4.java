//Importamos paquetes Scanner
import java.util.Scanner;
public class Java4 {

	public static void main(String[] args) {
		
		//Mostramos por pantalla, introducimos datos por teclado y los guardamos en una variable
		System.out.print("Introduzca la base de su triángulo: ");
		Scanner x = new Scanner(System.in);
		double base = x.nextDouble();
		
		System.out.print("Introduzca la altura de su triángulo: ");
		Scanner y = new Scanner(System.in);
		double altura = y.nextDouble();
		
		double area = (base * altura)/2;
		
		System.out.print("Su área es: " + area);

	}

}
