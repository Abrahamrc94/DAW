//Importamos paquete Scanner
import java.util.Scanner;

public class Java2 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y declaramos variable igual a datos por teclado
		System.out.print("Introduzca su número entero: ");
		Scanner x = new Scanner(System.in);
		int number = x.nextInt();
		
		//Decalramos variable
		int multiplo = 7;
		
		//Declaramos variable igual a operacion
		int resto = number%multiplo;
		
		//Iniciamos condicional
		if(resto == 0)

			System.out.println("Es múltiplo de 7");
			
		else
			System.out.println("Debe sumarle " + (multiplo - resto));

	}

}
