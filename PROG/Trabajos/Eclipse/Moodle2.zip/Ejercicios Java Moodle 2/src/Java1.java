//Importamos paquete Scanner
import java.util.Scanner;

public class Java1 {

	public static void main(String[] args) {
		
		//Imprimimos por pantalla, introducimos datos por teclado y declaramos variable igual a datos por teclado
		System.out.print("Introduza Base Imponible: ");
		Scanner x = new Scanner(System.in);
		double baseimponible = x.nextDouble();
		//Imprimimos por pantalla, introducimos datos por teclado y declaramos variable igual a datos por teclado
		System.out.print("Introduzca IVA: ");
		Scanner y = new Scanner(System.in);
		double iva = y.nextDouble()/100;
		
		//Declaramos variable igual a una operación
		double total = baseimponible + (iva * baseimponible);
		
		//Imprimimos por pantalla el resultado
		System.out.println("Su total es: (BASE IMPONIBLE) " + baseimponible + " + (IVA) " + iva + " = (TOTAL)" + total );

	}

}
