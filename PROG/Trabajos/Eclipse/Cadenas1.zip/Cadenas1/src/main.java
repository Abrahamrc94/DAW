import java.util.Scanner;
import java.util.regex.*;

public class main {

	public static void main(String[] args) {

		System.out.println("Ejercicio 1: ");
		
		Scanner x =  new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		System.out.print("Palabra 1: ");
		String palabra1 = x.nextLine();
		
		System.out.print("Palabra 2: ");
		String palabra2 = x.nextLine();
		
		if(palabra1.length() < palabra2.length()) {
			System.out.println("La palabra 1 es mas corta");
		}else if(palabra1.length() > palabra2.length()) {
			System.out.println("La palabra 2 es mas corta");
		}else {
			System.out.println("Las 2 palabras son iguales");
		}
		
		System.out.println("Ejercicio 2:");
		
		System.out.print("Escriba su nombre y apellidos: ");
		String nombreCompleto = x.nextLine();
		
		Pattern p = Pattern.compile("[aeiouáéíóú]+");
		Matcher sustituir = p.matcher(nombreCompleto);
		String resultado = sustituir.replaceAll("");
		System.out.println(resultado);
		
		
		System.out.println("Ejercicio 3:");
		
		String Cadena = x.nextLine();
		String CadenaInvertida = "";
		for (int i = Cadena.length()-1;i >= 0; i--) {
			CadenaInvertida = CadenaInvertida + Cadena.charAt(i);	
		}
		
		//Otra posibilidad
		
//		 String nueva = "";
//		
//		 char c[] = Cadena.toCharArray();
//		  for(int i = 0; i < c.length; i++){
//		  		nueva = c[i] + nueva;
//		  }
//		  
//		  System.out.println(nueva);
		 
		
		System.out.println(CadenaInvertida);
		
		System.out.println("Ejercicio 4:");
		
		System.out.print("Escriba una frase: ");
		String frase = y.nextLine();
		
		System.out.print("Escriba una palabra: ");
		String palabra = y.nextLine();
		
		int posicion, contador = 0;
		posicion = frase.indexOf(palabra);
		while(posicion != -1) {
			contador++;
			posicion = frase.indexOf(palabra, posicion + 1);
			
		}
		System.out.println(contador);
		
		System.out.println("Ejercicio 5:");
		
		System.out.println("Escriba una frases que sea palíndroma y sin tildes, si no, me autodestruiré en 5 segundos...");
		
		String Estoy = x.nextLine();
		String Terminando = "";
		String Todo = "";
		
		Pattern por = Pattern.compile(" ");
		Matcher fin = por.matcher(Estoy);
		String conio = fin.replaceAll(Todo);
		//System.out.println(conio);
		
		for (int i = conio.length()-1;i >= 0; i--) {
			Terminando = Terminando + conio.charAt(i);	
		}
		int contandoOtraVez = 0;
		char vaya [] = conio.toCharArray();
		char coniazo [] = Terminando.toCharArray();
		String bum = "BUM! A LA VERGA WEY!!";
		
		for(int i = conio.length()-1; i >= 0; i--) {
			if(vaya[i] == coniazo[i]) {
				contandoOtraVez++;
			}
			
		}if(contandoOtraVez == conio.length()) {
			System.out.println("POR FIN! LO HAS HECHO BIEN!!! Eah, dejalo ya un ratito...");
		}else {
			System.out.println("Autodestruyendo, empieza la cuenta atrás, contad vosotros hasta 5 que yo ya llevo mucho hecho...");
			try {
				Thread.sleep(5 * 1000);
				System.out.println(bum);
			}catch(Exception e) {
				System.out.println(e);
			}
		}
	}

}