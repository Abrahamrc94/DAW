import Enemigos.Enemigo;
import Heroes.Heore;
import java.util.Scanner;

public class Main {
	
	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		String boton;
		
		Heore heroe = new Heore();
		
		Enemigo enemigo = new Enemigo();
		
		System.out.println("Empieza el juego");
		System.out.println("Mata a tanto puedas");
		
		System.out.println("Nivel " + heroe.getLvl());
		System.out.println("Daño " + heroe.getDmg());
		
		System.out.println("Vaya! Tienes un enemigo con 20 de vida enfrente! ATACA!!");
		
		do {
			System.out.print("\nPara atacar escriba A: ");
			
			boton = x.nextLine();
			
			if(boton.equals("A")) {
				enemigo.setVida(enemigo.getVida() - heroe.getDmg());
				System.out.println("Le queda " + enemigo.getVida() + " de vida");
			}else{
				System.out.println("Vuelva a introducir el comando");
			}
			System.out.println("\nEl enemigo te ha atacado! Pierdes vida.");
			heroe.setVida(heroe.getVida() - enemigo.getDmg());
			System.out.println("Te queda " + heroe.getVida() + " de vida");
			
		}while(enemigo.getVida() > 0);
		
		System.out.println("\nHAS GANADO!!");
	}

}
