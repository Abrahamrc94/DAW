package Enemigos;

public class Enemigo {
	
	private int vida;
	
	private int dmg;

	public Enemigo() {
		dmg = 25;
		vida = 20;
		
	}
	
	public int getDmg() {
		return dmg;
	}
	

	
	public void setVida(int a) {
		vida = a;
	}
	
	public int getVida() {
		return vida;
	}

}
