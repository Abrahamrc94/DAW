package Heroes;

/**
 * @author jose
 *
 */
public class Heore {
	
	private final int vida_total;
	private int vida;
	
	private int lvl;
	private int exp;
	private int tope_exp;
	
	Arma espada;
	Pocion pocion;
	
	int dmg;

	public Heore() {
		
		espada = new Arma();
		vida_total = 75;
		vida = vida_total;
		lvl = 1;
		exp = 0;
		tope_exp = (int) (vida_total * 1.5);
		dmg = espada.getDmg();
		pocion = new Pocion();
	}
	
	public void subirLvl() {
		if (exp >= tope_exp) {
			lvl++;
		}
	}
	
	public int getLvl() {
		return lvl;
	}
	
	public int getDmg() {
		return dmg;
	}
	
	public void recuperaVida() {
		vida  = vida + pocion.getVida();
	}
	
	public void setVida(int a) {
		vida = a;
	}
	
	public int getVida(){
		return vida;
	}
	

}
