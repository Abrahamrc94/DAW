package Heroes;

public class Pocion {
	
	private final int vida_recupera;

	public Pocion() {
		
		vida_recupera = 50;
		
	}
	
	public int getVida() {
		return vida_recupera;
	}
	
	

}
