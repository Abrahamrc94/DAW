package Heroes;

public class Arma {
	
	private int dmg;
	private String name;

	public Arma() {
		
		dmg = 10;
		name = "Espadon";
		
	}
	
	public int getDmg() {
		return dmg;
	}
	
	public String getName() {
		return name;
	}

}
