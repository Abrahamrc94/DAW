
/**
 * @author jose
 *
 */
public class Main {
	
   static public void main(String args[]) {
      HoraExacta r = new HoraExacta(21, 30, 52);
      if(r.getHora() >= 0 && r.getHora() <= 24 && r.getMinutos() >= 0 && r.getMinutos() <= 60 && r.getSegundos() >= 0 && r.getSegundos() <= 60) {
    	  System.out.println(r);
    	  for (int i = 1; i <= 61; i++) { 
    		  r.inc();
    	  }
    	  System.out.println(r); 
    	  r.setHora(20); 
    	  System.out.println(r);
      }else {
    	  System.out.println("ERROR! Vuelve a introducir los datos");
      }
   }
}