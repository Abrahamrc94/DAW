package Interfaces;

public interface IPilaTabla {

	void apilar(int numero);

	void desapilar();
	
}
