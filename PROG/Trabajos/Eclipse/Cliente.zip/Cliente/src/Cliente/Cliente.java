/**
 * 
 */
package Cliente;

/**
 * @author Jose
 *
 */
public class Cliente {

	private String dni;
	private String nombre;
	private int edad;
	private double saldo;
	
	public Cliente() {
		// TODO Auto-generated constructor stub
	}

}
