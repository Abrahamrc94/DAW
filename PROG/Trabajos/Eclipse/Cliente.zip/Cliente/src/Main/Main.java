/**
 * 
 */
package Main;

/**
 * @author Jose
 *
 *Dise�ar la clase Cliente con los siguientes atributos: DNI, nombre, edad y saldo. Implementar un constructor y los m�todos toString() y equals() (este �ltimo basado en el DNI). 
 *Implementar la interfaz Comparable con un criterio de ordenaci�n basado tambi�n en el DNI. 
 *Implementar, asimismo, un comparador para hacer ordenaciones basadas en el nombre y otro basado en la edad. Crear una tabla con 5 clientes y mostrarlos ordenados por DNI, por nombre y por edad.
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
