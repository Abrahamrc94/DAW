package Interfaces;

public interface ICola {

	void apilar(int numero);

	void desapilar();
	
	
}
