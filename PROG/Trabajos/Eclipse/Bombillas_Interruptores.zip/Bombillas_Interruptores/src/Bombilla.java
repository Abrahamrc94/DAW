/*
 * La clase Bombilla se implementa con un indicador (apagada/encendida) de estado, que
 * ser� individual para cada bombilla (para cada objeto bombilla). Adem�s disponemos de
 * un interruptor general (que afecta a todas las bombillas). Este se implementa mediante 
 * un atributo est�tico, cuyo valor ser� el mismo para todos los objetos de la clase. 
 *
 */
public class Bombilla {
	public static boolean interruptorGeneral = true; //atributo est�tico
	private boolean interruptor; //interruptor (estado) que posee la bombilla
    
    public Bombilla (){
	    interruptor = false; //inicializamos la nueva bombilla. Est� apagada 
    }
    
    public void enciende (){
    	interruptor = true; //activamos el interruptor (a true)
    }

    public void apaga (){
    	interruptor = false; //desactivamos el interruptor
    }
    
    public boolean estado() {
    	boolean estado;
    	if (interruptorGeneral == true && interruptor == true) {
    		//si el interruptor de la bombilla est� activado y hay luz general
    		estado = true;
    	} else {
    		estado = false;
    	}
    	return (estado);
    }
    
    //Devuelve una cadena con el estado de la bombilla
    public String muestraEstado() {
    	String estado;
    	
    	if (estado() == true) {
    		estado = "Encendida";
    	} else {
    		estado = "Apagada";
    	}
    	return (estado);
    }

}

