import java.util.Scanner;

public class Java3Ejercicio5 {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		double base;
		double altura;
		
		System.out.print("Escriba base: ");
		base = x.nextDouble();
		
		System.out.print("Escriba altura: ");
		altura = y.nextDouble();
		
		System.out.println("Area = " + (base * altura));

	}

}
