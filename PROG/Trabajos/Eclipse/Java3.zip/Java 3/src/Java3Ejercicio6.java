import java.util.Scanner;

public class Java3Ejercicio6 {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		double base;
		double altura;
		
		System.out.print("Escribe base: ");
		base = x.nextDouble();
		
		System.out.print("Escribe altura: ");
		altura = y.nextDouble();
		
		System.out.println("Area = " + ((base * altura)/ 2));

	}

}
