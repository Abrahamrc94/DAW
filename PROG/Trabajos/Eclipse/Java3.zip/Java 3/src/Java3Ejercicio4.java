import java.util.Scanner;

public class Java3Ejercicio4 {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		double num1;
		double num2;
		
		System.out.println("Introduce los numero para operar: ");
		
		System.out.print("Número 1: ");
		num1 = x.nextDouble();
		
		System.out.print("Número 2: ");
		num2 = y.nextDouble();
		
		
		System.out.println("Suma = " + (num1 + num2));
		System.out.println("Resta = " + (num1 - num2));
		System.out.println("Multiplicación = " + (num1 * num2));
		System.out.println("División = " + (num1 / num2));

	}

}
