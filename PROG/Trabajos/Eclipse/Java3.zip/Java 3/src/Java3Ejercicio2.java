import java.util.Scanner;

public class Java3Ejercicio2 {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		final double PESETAS = 166.386;
		
		System.out.println("Conversor Euros --> Pesetas: ");
		double euros = x.nextDouble();
		
		System.out.println(euros + " Euros = " + euros * PESETAS + " Pesetas");
		

	}

}
