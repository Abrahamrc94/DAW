import java.util.Scanner;

public class Java3Ejercicio1 {
	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		Scanner y = new Scanner(System.in);
		
		int num1;
		int num2;
		
		System.out.println("Introduce 2 números");
		
		System.out.print("Número 1 = ");
		num1 = x.nextInt();
		
		System.out.print("Número 2 = ");
		num2 = y.nextInt();
		
		System.out.println("Resultado = " + num1 * num2);
	}

}
