import java.util.Scanner;

public class Java3Ejercicio3 {

	public static void main(String[] args) {
		Scanner x = new Scanner(System.in);
		final double EUROS = 0.006;
		
		System.out.println("Conversor Pesetas --> Euros: ");
		double pesetas = x.nextDouble();
		
		System.out.println(pesetas + " Pesetas = " + pesetas * EUROS + " Euros");
		

	}

}
