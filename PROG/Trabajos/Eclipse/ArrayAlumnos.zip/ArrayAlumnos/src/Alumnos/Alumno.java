package Alumnos;
import java.util.Scanner;

/**
 * @author Jose
 * @version 1.1
 * 
 */

public class Alumno {

	private Scanner x = new Scanner(System.in);
	private String Nombre;
	private int edad;
	private int longArray;
	private int nModulos [];
	private int notas;
	private double suma = 0;
	private boolean correcto;
	
 /**
  * @param x Scanner para String
  * @param Nombre asigna el nombre
  * @param edad Determina la edad del alumno
  * @param longArray Determina la longitud de los modulos
  * @param nModulos Array de los modulos
  * @param notas Determina las notas de cada modulo
  * @param suma Determina la media del alumno
  * @param correcto Controla el bucle del metodo posModulo()
  */
	
	//Metodo constructor
	public Alumno(String nombre, int edad) {
		
		this.Nombre = nombre;
		this.edad = edad;
	}
	
	//Getters y Setters
	public double getSuma() {
		return suma;
	}
	
	public int getNotas() {
		return notas;
	}

	public void setNotas(int notas) {
		this.notas = notas;
	}

	public String getNombre() {
		return Nombre;
	}

	public void setNombre(String nombre) {
		Nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getLongArray() {
		return longArray;
	}

	public void setLongArray(int longArray) {
		this.longArray = longArray;
	}
	
	//Metodo para introducir las notas en cada modulo y comprobar que estan introducidas correctamente
	public void posModulos() {

		correcto = false;
		
		nModulos = new int [longArray];
		
		for(int i = 0; i < longArray; i++) {
			
			System.out.println("Introduzca la nota del modulo " + i);
			
			do {
				setNotas(x.nextInt());
				if(notas > 10 || notas <= 0) {
					System.out.println("Vuelva a introducir una nota entre 0 y 10, incluyendo el 10");
				}else {
					correcto = true;
				}
			}while(correcto == false);
			
			nModulos [i] = notas;
		}
		
	}
	
	//Metodo para calcular la media de cada alumno
	public void mediaAlumno() {
		
		for(int i = 0; i<longArray; i++) {
			
			suma = nModulos[i] + suma;
		}
		
		suma = suma / longArray;
	}

}
