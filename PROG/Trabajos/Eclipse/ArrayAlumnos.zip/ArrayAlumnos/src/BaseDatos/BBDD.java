package BaseDatos;
import Alumnos.Alumno;

import java.util.Scanner;

/**
 * @author Jose
 * @version 1.1
 */

public class BBDD {
	
	//Atributos de la clase
	private Scanner x = new Scanner(System.in);
	private Scanner y = new Scanner(System.in);
	private String paramNombre;
	private int paramInt;
	private double sumaTotal = 0;
	private boolean correcto;
	private boolean existe;
	private boolean encontrado;
	private Alumno save;
	private Alumno alumno;
	private int numAlumnos;
	private Alumno baseDatosAlumnos [];
	
 /**
  * @param x Scanner para String
  * @param y Scanner para int
  * @param paramNombre Asigna los valores del Scanner x
  * @param paramInt Asigna los valores del Scanner y
  * @param sumaTotal Suma de todas las medias de cada alumno
  * @param numAlumnos Longitud del array de baseDatosAlumnos
  * @param baseDatosAlumnos Array de tipo Alumno para almacenar cada objeto Alumno
  * @param correcto Controla cada bucle del metodo intoAlumnos()
  * @param existe Controla cada bucle del metodo intoAlumnos()
  * @param encontrado Controla el buble de modNotas
  * @param save Guarda el objeto Alumno de manera permanente hasta que se quiera usar
  * @param alumno Objeto de la clase Alumno
  */
	
	//Metodo constructor
	public BBDD() {
		
	}
	
	//Metodo para introducir alumnos en baseDatosAlumnos[]
	public void intoAlumnos() {
		
		//Cuantos alumnos se van a introducir
		System.out.print("Cuantos alumnos va a introducir: ");
		numAlumnos = y.nextInt();
		baseDatosAlumnos = new Alumno [numAlumnos];
		correcto = false;
		
		
		//Bucle para introducir cada alumno
		for(int i = 0; i<numAlumnos; i++) {
		
			existe = false;
			
			alumno = new Alumno(paramNombre, paramInt);
			
			System.out.print("Introduzca el nombre de su alumno " + (i+1) + ": ");
			
			//Introducimos el nombre del alumno y comprobamos que no esta repetido
			if(i != 0) {
				do {
					alumno.setNombre(paramNombre = x.nextLine());
					for(int j = 0; j < i; j++) {
						if(!baseDatosAlumnos[j].getNombre().equals(paramNombre) ) {
							existe = true;
						}else {
							System.out.println("Vuelve a introducir el nombre, est� repetido");
							existe = false;
						}
					}
				}while(existe == false);
			}else {
				alumno.setNombre(paramNombre = x.nextLine());
			}
			
			System.out.print("Introduzca la edad de su alumno " + (i+1) + ": ");
			
			//Introducimos la edad el alumno y comprobamos que no esta repetido
				do {
					alumno.setEdad(paramInt = y.nextInt());
					if(alumno.getEdad() < 0) {
						System.out.println("Vuelva a introducir una edad mayor que 0");
					}else {
						correcto = true;
					}
				}while(correcto == false);
			
			//Introducimos el numero de modulos en los que esta matriculado
			System.out.print("Introduzca el numero de modulos en los que est� matriculado su alumno " + (i+1) + ": ");
			alumno.setLongArray(paramInt = y.nextInt());
			
			alumno.posModulos();
			
			//Guardamos el alumno en la posicion i
			baseDatosAlumnos[i] = alumno;
		}
		
	}
	
	//Metodo para modificar las notas de cada alumno, comprobamos que se ha encontrado y salimos con la palabra FIN
	public void modNotas(){
		
		do {
			encontrado = false;
			
			System.out.println("Introduzca el nombre del alumno del que quiere modificar sus notas, escriba 'FIN' en mayusculas para finalizar: ");
			paramNombre = x.nextLine();
			for(int i = 0; i < numAlumnos; i++) {
				if(baseDatosAlumnos[i].getNombre().equals(paramNombre)) {
					System.out.println("Modifique su nota");
					baseDatosAlumnos[i].posModulos();
					encontrado = true;
					break;
				}
			}if(encontrado == false && !paramNombre.equals("FIN")) {
				System.out.println("Alumno no encontrado, vuelva a intentarlo por favor.");
			}
		}while(!paramNombre.equals("FIN"));
		
	}
	
	//Metodo para ordenar los alumnos alfabeticamente
	public void ordenAlumnos() {
		
		for(int i = 1; i < numAlumnos; i++) {
			for(int j = i; j > 0; j--) {
				if(baseDatosAlumnos[j].getNombre().compareTo(baseDatosAlumnos[j - 1].getNombre()) < 0) {
					save = baseDatosAlumnos[j];
					baseDatosAlumnos[j] = baseDatosAlumnos[j-1];
					baseDatosAlumnos[j-1] = save;
				}
			}
		}
		
	}
	
	//Metodo para mostrar los alumnos con las 3 primeras letras en mayusculas junto a su nota media
	public void mostrarAlumnos() {
		
		for(int i = 0; i < numAlumnos; i++) {
			
			baseDatosAlumnos[i].mediaAlumno();
			System.out.printf("\nNota media del alumno " + baseDatosAlumnos[i].getNombre().substring(0, 3).toUpperCase() + baseDatosAlumnos[i].getNombre().substring(3) + ": " +  "%.2f", baseDatosAlumnos[i].getSuma());
			
			sumaTotal = baseDatosAlumnos[i].getSuma() + sumaTotal; 
		}
	}
	
	//Metodo para motrar el total de alumnos que tenemos en la base de datos junto con la media general
	public void motrarTotal() {
		
		System.out.println();
		System.out.println("\nNumero de alumnos: " + numAlumnos);
		System.out.printf("Media general: " + "%.2f", sumaTotal/numAlumnos);
	}

}
