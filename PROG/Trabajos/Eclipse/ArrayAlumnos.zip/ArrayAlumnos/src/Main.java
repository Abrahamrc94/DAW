import BaseDatos.BBDD;

/**
 * @author Jose
 * @version 1.1
 */

public class Main {

	public static void main(String[] args) {
		
		BBDD base = new BBDD();
		
		//Controlamos la excepcion que salta cuando introduzcamos un valor no permitido en una variable
		try {
			base.intoAlumnos();
			base.modNotas();
			base.ordenAlumnos();
			base.mostrarAlumnos();
			base.motrarTotal();
		}catch(Exception e) {
			System.out.println("\nValor mal introducido:\nEdad, Notas, Numero alumnos: Numeros.\nNombre: Letras.");
		}
		
	}

}
