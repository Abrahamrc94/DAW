import java.util.Random;

public class Java6Ejercicio2 {

	public static void main(String[] args) {
		
		//Declaracion de Arrays, variables y Random.
		
		Random azar = new Random();
				
		String[] palo = new String[4];
		
		palo[0] = "Corazones";
		
		palo[1] = "Picas";
		
		palo[2] = "Diamantes";
		
		palo[3] = "Treboles";
		
		int[] numero = {2,3,4,5,6,7,8,9,10};
		
		String[] letras = {"J", "Q", "K", "AS"};
		
		System.out.println("Tu mano");
		
		//Tu mano
		//Bucle de asignacion de 5 cartas al azar, Palo + Numero si es VERDADERO/Palo + Letra si es FALSO;
		for(int i = 0; i<5; i++) {
			boolean valor = azar.nextBoolean();
			if(valor == true) {
				System.out.println(numero[new Random().nextInt(9)] + " de " + palo[new Random().nextInt(4)]);
			}else if(valor == false){
				System.out.println(letras[new Random().nextInt(4)] + " de " + palo[new Random().nextInt(4)]);
			}
		}
		
		//Mano del contrincante
		
		System.out.println("Mano del contrincante");
		
		for(int i = 0; i<5; i++) {
			boolean valor = azar.nextBoolean();
			if(valor == true) {
				System.out.println(numero[new Random().nextInt(9)] + " de " + palo[new Random().nextInt(4)]);
			}else if(valor == false){
				System.out.println(letras[new Random().nextInt(4)] + " de " + palo[new Random().nextInt(4)]);
			}
		}
	}
}
