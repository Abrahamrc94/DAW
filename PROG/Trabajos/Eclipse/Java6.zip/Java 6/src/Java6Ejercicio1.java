
public class Java6Ejercicio1 {

	public static void main(String[] args) {
		System.out.println("Tirando dados... ");
		
		int dados;
		int resultado = 0;
		
		for(int i=1; i<=3; i++) {
			dados = (int)(Math.random()*10);
			System.out.println(dados);
			resultado += dados;
			
		}System.out.println(resultado);
	}

}
