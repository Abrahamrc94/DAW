/**
 * 
 */
package Participantes;

/**
 * @author Jose
 *
 */
public class Participante {

	protected String nombre;
	protected String pais;
	protected int añoNacimiento;
	
	public Participante() {
		
	}

	public String getNombre() {
		return nombre;
	}

	/**
	 * 
	 * @param nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPais() {
		return pais;
	}

	/**
	 * 
	 * @param pais
	 */
	public void setPais(String pais) {
		this.pais = pais;
	}

	public int getAñoNacimiento() {
		return añoNacimiento;
	}

	/**
	 * 
	 * @param añoNacimiento
	 */
	public void setAñoNacimiento(int añoNacimiento) {
		this.añoNacimiento = añoNacimiento;
	}
	
	

}
