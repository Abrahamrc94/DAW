/**
 * 
 */
package Participantes;

/**
 * @author Jose
 *
 */
public class Arbitro extends Participante{

	public enum categoria{PRINCIPAL, ADJUNTO, AUXILIAR};
	private categoria cat;
	private boolean internacional;
	
	public categoria getCat() {
		return cat;
	}

	/**
	 * 
	 * @param cat
	 */
	public void setCat(categoria cat) {
		this.cat = cat;
	}

	public boolean isInternacional() {
		return internacional;
	}

	/**
	 * 
	 * @param internacional
	 */
	public void setInternacional(boolean internacional) {
		this.internacional = internacional;
	}

	public Arbitro() {
		
	}
	
}
