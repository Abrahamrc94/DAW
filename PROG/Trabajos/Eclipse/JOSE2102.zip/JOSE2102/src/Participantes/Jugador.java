/**
 * 
 */
package Participantes;

/**
 * @author Jose
 *
 */
public class Jugador extends Participante{

	private int posicion;
	private boolean profesional;
	public static boolean ocupado;
	
	public int getPosicion() {
		return posicion;
	}

	/**
	 * 
	 * @param posicion
	 */
	public void setPosicion(int posicion) {
		this.posicion = posicion;
	}

	public boolean isProfesional() {
		return profesional;
	}

	/**
	 * 
	 * @param profesional
	 */
	public void setProfesional(boolean profesional) {
		this.profesional = profesional;
	}

	public Jugador() {
		
	}

	public boolean isOcupado() {
		return ocupado;
	}

	/**
	 * 
	 * @param ocupado
	 */
	public void setOcupado(boolean ocupado) {
		this.ocupado = ocupado;
	}

	public String consulta() {
		return "Nombre: " + nombre + " - Profesional: " + profesional;
	}
	
	
	
}
