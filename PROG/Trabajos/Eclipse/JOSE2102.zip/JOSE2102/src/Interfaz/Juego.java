package Interfaz;

public interface Juego {
	
	void registrarGanador(Object jugadorGanador);
	void registrarMovimientos(int numeroMovimientos);
	
}
