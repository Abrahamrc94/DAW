/**
 * 
 */
package Main;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import Participantes.Arbitro;
import Participantes.Jugador;
import Torneo.Fecha;
import Torneo.Partida;

/**
 * @author Jose
 *
 */
public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		int opcion;
		int opcion2;
		int opJugador1;
		int opJugador2;
		int opArbitro;
		int jugadorGanador;
		int mov;
		int numeroPartida = 0;
		Jugador jugadorParaVer;
		
		Arbitro arbitro;
		Jugador jugador;
		Partida partida = new Partida();
		Fecha fecha;
		
		ArrayList <Object> jugadores = new ArrayList<>();
		ArrayList <Object> arbitros = new ArrayList<>();
		Object partidasTotal [] = new Object[100];
		
		do {
			System.out.print("Que desea realizar:\n1- Alta de participante.\n2- Inicio de partida.\n3- Fin de partida.\n4- Listado de jugadores.\n5- Estadísticas de un jugador.\n6- Estadísticas del torneo.\n7- Salir.\nOpcion: ");
			opcion = x.nextInt();
			
			if(opcion == 1) {
				System.out.print("Si desea añadir un jugador indique 1, en caso de arbitro indique 2: ");
				opcion2 = x.nextInt();
				if(opcion2 == 1) {
					jugador = new Jugador();
					jugador.setAñoNacimiento(1954);
					jugador.setNombre("Antonio");
					jugador.setPais("España");
					jugador.setPosicion(16);
					jugador.setProfesional(false);
					jugador.setOcupado(false);
					jugadores.add(jugador);
				}else if(opcion2 == 2) {
					arbitro = new Arbitro();
					arbitro.setAñoNacimiento(1967);
					arbitro.setInternacional(true);
					arbitro.setNombre("David");
					arbitro.setPais("Inglaterra");
					arbitro.setCat(Arbitro.categoria.PRINCIPAL);
					arbitros.add(arbitro);
				}
			}else if(opcion == 2) {
				
				
				System.out.print("Introduzca el jugador 1 que quiere introducir: ");
				opJugador1 = x.nextInt();
				
				System.out.print("Introduzca el jugador 2 que quiere introducir: ");
				opJugador2 = x.nextInt();
				
				System.out.print("Introduzca el arbitro que quiere introducir: ");
				opArbitro = x.nextInt();
				if(partida.isTerminada() == true) {
				
					partida = new Partida(jugadores.get(opJugador1),jugadores.get(opJugador2), arbitros.get(opArbitro), new Fecha(5,6,1993));
					partida.setTerminada(false);
				}else {
					System.out.println("Una partida sigue en curso aun.");
				}
				
				
			}else if(opcion == 3) {
				System.out.println("Ha finalizado la partida con id: " + Partida.id);
				System.out.print("¿Quien ha sido el ganador? ");
				jugadorGanador = x.nextInt();
				
				System.out.print("¿Cuantos movimientos ha tenido? ");
				mov = x.nextInt();
				
				partida.registrarGanador(jugadores.get(jugadorGanador));
				partida.registrarMovimientos(mov);
				
				partidasTotal[numeroPartida] = partida;
				numeroPartida = numeroPartida + 1;
			}else if(opcion == 4) {
				for(int i = 0; i < jugadores.size(); i++) {
					jugadorParaVer = (Jugador) jugadores.get(i);
					System.out.println(jugadorParaVer.consulta());
				}
				
			}else if(opcion == 5) {
				
			}else if(opcion == 6) {
				
			}
		}while(opcion != 7);
	}

}
