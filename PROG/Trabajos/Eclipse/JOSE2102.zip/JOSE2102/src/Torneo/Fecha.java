/**
 * 
 */
package Torneo;

/**
 * @author Jose
 *
 */
public class Fecha {

	private int dia;
	private int mes;
	private int anyo;
	
	/**
	 * 
	 * @param dia
	 * @param mes
	 * @param anyo
	 */
	public Fecha(int dia, int mes, int anyo) {
		
		this.dia = dia;
		this.mes = mes;
		this.anyo = anyo;
	}

}
