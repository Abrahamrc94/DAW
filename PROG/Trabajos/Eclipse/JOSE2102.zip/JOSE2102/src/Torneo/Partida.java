package Torneo;

import Interfaz.Juego;

/**
 * @author Jose
 *
 */
public class Partida implements Juego{

	private Object jugador1;
	private Object jugador2;
	private Object arbitro;
	private Object fecha;
	private enum fichaGanador{B, N};
	private fichaGanador fichaG;
	private int numeroMovimientos;
	private Object jugadorGanador;
	private int idPartida;
	public static int id = 0;
	private boolean terminada = true;
	
	/**
	 * 
	 * @param jugador1
	 * @param jugador2
	 * @param arbitro
	 * @param fecha
	 * @param fichaG
	 * @param numeroMovimientos
	 */
	public Partida(Object jugador1, Object jugador2, Object arbitro, Object fecha) {
		
		idPartida = Partida.id++;
		this.jugador1 = jugador1;
		this.jugador2 = jugador2;
		this.arbitro = arbitro;
		this.fecha = fecha;
	}
	
	public Partida() {
		
	}

	@Override
	public void registrarGanador(Object jugadorGanador) {
	
		this.jugadorGanador = jugadorGanador;
	}

	@Override
	public void registrarMovimientos(int numeroMovimientos) {
		
		this.numeroMovimientos = numeroMovimientos;
	}

	public boolean isTerminada() {
		return terminada;
	}

	/**
	 * 
	 * @param terminada
	 */
	public void setTerminada(boolean terminada) {
		this.terminada = terminada;
	}

}
