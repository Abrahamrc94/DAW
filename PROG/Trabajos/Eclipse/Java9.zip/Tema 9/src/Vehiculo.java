
public class Vehiculo {
	
	private String vehiculosCreados;
	private int kilometrosTotales;
	Bicicleta b = new Bicicleta();
	Coche c = new Coche();

	public Vehiculo() {
		
		
	}
	public void setkmTotales() {
		kilometrosTotales = b.getKmRecorridos() + c.getKmRecorridos();	
	}
	
	public int getkmTotales() {
		return kilometrosTotales;
	}

}
