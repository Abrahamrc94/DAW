import java.util.Scanner;

public class Bicicleta {
	
	private int kilometrosRecorridos;
	private Scanner x = new Scanner(System.in);
	private int vueltas;

	public Bicicleta() {
		
	}
	
	public int getKmRecorridos() {
		return kilometrosRecorridos;
	}
	
	public void andarBici() {
		
		System.out.println("Empezemos con la bicicleta");
		
		kilometrosRecorridos = 0;
		
		do {
			System.out.print("¿Quiere Seguir? Escriba 0 para seguir o 1 para deternse: ");
			vueltas = x.nextInt();
			kilometrosRecorridos += 10;
		}while (vueltas != 1);
		System.out.println("Ha recorrido " + kilometrosRecorridos + " km");
		
	}
	

	
	public void caballitoBici() {
		System.out.println("Haciendo el caballito");
	}

}
