import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner x = new Scanner(System.in);
		
		Bicicleta b = new Bicicleta();
		Coche c = new Coche();
		Vehiculo v = new Vehiculo();
		int opcion;
		
		System.out.print("Elija una opcion: ");
		opcion = x.nextInt();
		
		if(opcion == 1) {
			b.andarBici();
		} else if(opcion == 2) {
			b.caballitoBici();
		}else if(opcion == 3) {
			c.andarCoche();
		}else if(opcion == 4) {
			c.quemandoRueda();
		}else if(opcion == 5) {
			b.getKmRecorridos();
		}else if(opcion == 6) {
			c.getKmRecorridos();
		}else if(opcion == 7) {
			v.getkmTotales();
		}else if(opcion == 8) {
			System.out.println("Ha elegido salir");
		}

	}

}
