import java.util.Scanner;

public class Coche {
	
	private int kilometrosRecorridos;
	private Scanner x = new Scanner(System.in);
	private int vueltas;
	private int quemaRuedas = 0;
	private int vueltaRuedas;

	public Coche() {
		
	}
	
	public int getKmRecorridos() {
		return kilometrosRecorridos;
	}
	
	public void andarCoche() {
		
		System.out.println("Empezemos con el coche");
		
		kilometrosRecorridos = 0;
		
		do {
			System.out.print("¿Quiere Seguir? Escriba 0 para seguir o 1 para deternse: ");
			vueltas = x.nextInt();
			kilometrosRecorridos += 10;
		}while (vueltas != 1);
		System.out.println("Ha recorrido " + kilometrosRecorridos + " km");
		
	}
	

	
	public void quemandoRueda() {
		
			System.out.println("Quemando rueda! Que guay eres!...Ten cuidado '¬¬");
			do {
				if(quemaRuedas < 10) {
				System.out.print("¿Quiere Seguir quemando? Escriba 0 para seguir o 1 para deternse: ");
				vueltaRuedas = x.nextInt();
				quemaRuedas++;
				}else if(quemaRuedas >= 10) {
					System.out.println("Te has cargado las ruedas... CAPULLO!");
					break;
				}
			}while (vueltaRuedas != 1);
			System.out.println("Ya ha terminado todo T-T ... Ahora vas a tener que cambiar las ruedas... V.v'");
			
		
		
	}

}
