
public class Enemigos {
	//Atributos
	private final String MARCIANO = "marciano";
	private final String VENECIANO = "veneciano";
	
	private String nombre;
	private String tipo; 
//	private Enum tipo {MARCIANO,VENECIANO};
	
	//constructor
	public Enemigos(String nombre, String tipo) {
		this.nombre=nombre;
		this.tipo=tipo;
	}
	
	//constructor
	public Enemigos() {
		super();
	}

	//Setter & getter
	/**
	 * @return the nombre
	 */
	public String getNombre() {
		return nombre;
	}

	/**
	 * @param nombre the nombre to set
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	public String toString() {
		return("Enemigo: "+ this.nombre + "\nTipo: "+ this.tipo);
		
	}
	
	
	
	
	
	
	

}
