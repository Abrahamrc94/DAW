
public class Armas {

}
