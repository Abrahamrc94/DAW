import java.util.Scanner;


/**
 * 
 * @author juanma
 * @version 0.1
 * 
 */


 class Videojuego {
	//atributos
	private Enemigos enemigos; //enemigos del juego
	private Heroes heroes;// heroes del juego
	private Armas armas;//armas del juego
	private int numPartidas;
	
	/**
	 * Constructor de la clase
	 * Inicializa los atributos
	 */

	public Videojuego(Enemigos enemigos, Heroes heroes, Armas armas, int numPartidas) {
		super();
		this.enemigos = enemigos;
		this.heroes = heroes;
		this.armas = armas;
		this.numPartidas = numPartidas;
	}

	public Videojuego(Enemigos enemigo) {
		super();
		this.enemigos = enemigo;
	}

	/**
	 * Metodo para obtener el numero de partidas del juego
	 * @return numPartidas
	 */
	public int getNumPartidas() {
		return this.numPartidas;
	}
	
	/**
	 * Metodo para asignar el numero de partidas permitidas
	 * @param numPartidas
	 */
	public void setNumPartidas(int numPartidas) {
		this.numPartidas = numPartidas;
	}

	public Enemigos getEnemigos() {
		return enemigos;
	}

	/**
	 * @return the heroes
	 */
	public Heroes getHeroes() {
		return heroes;
	}

//	/**
//	 * @param heroes the heroes to set
//	 */
//	public void setHeroes(String heroes) {
//		this.heroes = heroes;
//	}
//
//	/**
//	 * @return the armas
//	 */
//	public String getArmas() {
//		return armas;
//	}
//
//	/**
//	 * @param armas the armas to set
//	 */
//	public void setArmas(String armas) {
//		this.armas = armas;
//	}
//
//	/**
//	 * @param enemigos the enemigos to set
//	 */
//	public void setEnemigos(String enemigos) {
//		this.enemigos = enemigos;
//	}
//	
	public void getComienzo() {
		System.out.println("El juego ha comenzado");
	}
//	
//	public String toString (){
//        String mensaje = "Te enfrentas a " + enemigos + " con el heroe " + heroes + " con  " + armas + ". Tienes " + numPartidas + " partida/s. Buena suerte patriota";
//        return mensaje;
//    }
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		//variables
		String armas;
		Enemigos enemigos = new Enemigos();
		String heroes;
		int numPartidas;
		
		//declaracion de variables
		System.out.print("Elije el nombre de los enemigos a los que te enfrentaras: ");
		enemigos.setNombre(s.nextLine());
		System.out.print("Elije el tipo de los enemigos a los que te enfrentaras (veneciano, marciano): ");
		enemigos.setTipo(s.nextLine());
		System.out.println("Su elección ha sido:\n"+enemigos.toString());
				
		
		Videojuego v = new Videojuego(enemigos);//, heroes, armas, numPartidas );
		v.getComienzo();
		System.out.println(v.toString());
	}
	
	
}
